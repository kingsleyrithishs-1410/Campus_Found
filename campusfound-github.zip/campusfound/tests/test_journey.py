"""The complete 23-step user journey from the specification, end to end,
through real HTTP requests against the Flask app."""
import os
import re
from datetime import date

from PIL import Image

from conftest import image_bytes, login, make_client, register
from extensions import db
from models import (AuditLog, CampusLocation, Claim, ClaimStatus, Item, ItemStatus, ItemType,
                    Message, Notification, Report, User)


LIBRARY = "Library"


def test_complete_user_journey(app):
    today = date.today().isoformat()
    library = CampusLocation.query.filter_by(name=LIBRARY).first()

    # 1. Student A registers.
    a = make_client(app)
    r = register(a, "Student Alpha", "student.a@college.edu")
    assert r.status_code == 200 and b"Welcome, Student" in r.data
    student_a = User.query.filter_by(email="student.a@college.edu").one()
    assert student_a.password_hash != "Campus123" and student_a.check_password("Campus123")

    # 2-3. Student A finds a wallet and clicks "I FOUND SOMETHING".
    r = a.get("/items/new?type=found")
    assert r.status_code == 200 and b"I found something" in r.data

    # 4-6. Wallet details, a photo (with GPS EXIF) and "Library" picked on the campus map.
    r = a.post("/items/new", data={
        "type": "found",
        "title": "Black leather wallet",
        "category": "Wallet",
        "description": "Black leather wallet found under a table in the reading room.",
        "event_date": today,
        "location_name": LIBRARY,
        "latitude": f"{library.latitude + 0.0002:.6f}",     # clicked a few metres away
        "longitude": f"{library.longitude:.6f}",
        "location_details": "Ground floor reading room",
        "photo": (image_bytes(with_gps=True), "wallet.jpg"),
    }, content_type="multipart/form-data", follow_redirects=True)
    assert r.status_code == 200, r.data[:500]
    found = Item.query.filter_by(title="Black leather wallet").one()
    assert found.item_type == ItemType.FOUND and found.status == ItemStatus.ACTIVE
    assert found.location_name == LIBRARY and found.latitude is not None
    assert found.image_path and found.image_path != "wallet.jpg"
    stored = os.path.join(app.config["UPLOAD_ROOT"], "items", found.image_path)
    assert os.path.isfile(stored)
    assert 0x8825 not in Image.open(stored).getexif(), "GPS EXIF must be stripped"

    # 7. The found report appears in the public feed.
    r = a.get("/feed")
    assert b"stretched\">Black leather wallet</a>" in r.data and b"FOUND" in r.data

    # 8. Student B registers.
    b = make_client(app)
    assert b"Welcome, Student" in register(b, "Student Beta", "student.b@college.edu").data
    student_b = User.query.filter_by(email="student.b@college.edu").one()

    # 9. Student B reports a lost wallet at the Library.
    r = b.post("/items/new", data={
        "type": "lost",
        "title": "Black wallet",
        "category": "Wallet",
        "description": "Black leather wallet with my library card and some cash inside.",
        "event_date": today,
        "location_name": LIBRARY,
        "latitude": "", "longitude": "",
    }, follow_redirects=True)
    assert r.status_code == 200
    lost = Item.query.filter_by(title="Black wallet").one()
    assert lost.item_type == ItemType.LOST and lost.status == ItemStatus.ACTIVE
    assert lost.latitude == library.latitude, "predefined location fills coordinates"

    # 10. The matching system identifies the found wallet as a possible match.
    assert b"POSSIBLE MATCH" in r.data
    assert b"Your lost item may match this found report." in r.data
    assert b"Black leather wallet" in r.data
    assert Notification.query.filter_by(user_id=student_b.user_id, kind="possible_match").count() == 1
    assert b"Possible match" in b.get("/feed").data   # banner on the feed too

    # 11. Student B opens the found report.
    r = b.get(f"/items/{found.item_id}")
    assert r.status_code == 200
    # 12. ...and sees "I THINK THIS IS MINE".
    assert b"I THINK THIS IS MINE" in r.data
    r = b.get(f"/items/{found.item_id}/claim")
    assert b"PROVE THAT THIS ITEM BELONGS TO YOU" in r.data

    # A claim cannot be made by just clicking: empty proof is rejected.
    r = b.post(f"/items/{found.item_id}/claim", data={"proof": "", "confirm": "yes"})
    assert r.status_code == 400 and Claim.query.count() == 0

    # 13. Student B provides ownership proof (with a private photo).
    r = b.post(f"/items/{found.item_id}/claim", data={
        "proof": "My initials S.B. are written inside the wallet, next to a torn bus pass.",
        "unique_marks": "Small cut on the back corner",
        "purchase_info": "Bought at the campus store in June",
        "lost_item_id": str(lost.item_id),
        "confirm": "yes",
        "proof_photo": (image_bytes(color=(90, 40, 10)), "old-photo.jpg"),
    }, content_type="multipart/form-data", follow_redirects=True)
    assert r.status_code == 200
    claim = Claim.query.one()
    assert claim.status == ClaimStatus.PENDING and claim.claimant_id == student_b.user_id
    assert claim.lost_item_id == lost.item_id
    assert db.session.get(Item, found.item_id).status == ItemStatus.CLAIM_REQUESTED
    assert Notification.query.filter_by(user_id=student_a.user_id, kind="claim_received").count() == 1

    # Duplicate claims are prevented.
    r = b.post(f"/items/{found.item_id}/claim", data={"proof": "x" * 30, "confirm": "yes"},
               follow_redirects=True)
    assert Claim.query.count() == 1

    # 14. The system creates an item-specific protected chat (B landed in it).
    assert f"claim #{claim.claim_id}".encode() in r.data.lower()
    assert Message.query.filter_by(claim_id=claim.claim_id, sender_id=None).count() == 1

    # 15. Suggested messages are displayed.
    for s in [b"Where exactly was the item found?", b"What is the preferred safe handover point?"]:
        assert s in r.data
    assert b"Keep this conversation related to the reported item" in r.data

    # B sends a suggested message (JSON, as chat.js does) and an edited one (form post).
    r = b.post(f"/claims/{claim.claim_id}/messages", json={"body": "Where exactly was the item found?"},
               headers={"Accept": "application/json"})
    assert r.status_code == 200 and r.get_json()["ok"]
    r = b.post(f"/claims/{claim.claim_id}/messages",
               data={"body": "Where exactly was the item found? I sat near the window."})
    assert r.status_code == 302
    msgs = Message.query.filter(Message.claim_id == claim.claim_id, Message.sender_id.isnot(None)).all()
    assert [m.is_suggestion for m in msgs] == [True, False]

    # Chat filter blocks phone numbers and payment requests.
    r = b.post(f"/claims/{claim.claim_id}/messages", json={"body": "Call me on 98765 43210"})
    assert r.status_code == 400 and "Phone numbers" in r.get_json()["error"]
    r = b.post(f"/claims/{claim.claim_id}/messages", json={"body": "Send me your UPI and I will pay a reward"})
    assert r.status_code == 400

    # 16. Student A reviews the proof (visible to A in the claim panel, incl. private photo).
    r = a.get(f"/claims/{claim.claim_id}/chat")
    assert r.status_code == 200
    assert b"My initials S.B." in r.data and b"Approve claim" in r.data
    assert a.get(f"/claims/{claim.claim_id}/proof-image").status_code == 200
    poll = a.get(f"/claims/{claim.claim_id}/messages.json?after=0").get_json()
    assert any(m["body"].startswith("Where exactly") for m in poll["messages"])
    a.post(f"/claims/{claim.claim_id}/messages", json={"body": "Found it under a table by the window."})

    # 17. Student A approves the claim.
    r = a.post(f"/claims/{claim.claim_id}/approve", follow_redirects=True)
    assert r.status_code == 200
    db.session.expire_all()
    assert db.session.get(Claim, claim.claim_id).status == ClaimStatus.APPROVED
    assert db.session.get(Item, found.item_id).status == ItemStatus.CLAIM_APPROVED
    assert Notification.query.filter_by(user_id=student_b.user_id, kind="claim_approved").count() == 1

    # 18. Both users arrange a safe campus handover.
    r = b.post(f"/claims/{claim.claim_id}/messages", json={"body": "Can we meet at the Main Block entrance?"})
    assert r.get_json()["message"]["suggestion"] is True
    r = a.post(f"/claims/{claim.claim_id}/messages", json={"body": "Yes, at 4 pm today at the Library entrance."})
    assert r.get_json()["ok"]

    # 19. Student A marks the item as returned.
    r = a.post(f"/claims/{claim.claim_id}/returned", follow_redirects=True)
    assert r.status_code == 200

    # 20. Item status becomes COMPLETED (with completed_at); claim is "returned".
    db.session.expire_all()
    found = db.session.get(Item, found.item_id)
    assert found.status == ItemStatus.COMPLETED and found.completed_at is not None
    assert db.session.get(Claim, claim.claim_id).status == ClaimStatus.RETURNED
    assert db.session.get(Item, lost.item_id).status == ItemStatus.COMPLETED, "linked lost report closes too"
    assert Notification.query.filter_by(user_id=student_b.user_id, kind="item_returned").count() == 1
    # The conversation is closed for new messages.
    r = b.post(f"/claims/{claim.claim_id}/messages", json={"body": "Thanks!"})
    assert r.status_code == 409

    # 21. Item disappears from the active public feed (for everyone).
    c = make_client(app)
    register(c, "Student Gamma", "student.c@college.edu")
    for client in (a, b, c):
        assert b"stretched\">Black leather wallet</a>" not in client.get("/feed").data
    assert c.get(f"/items/{found.item_id}").status_code == 404   # outsiders can't open it
    assert c.get(f"/media/items/{found.image_path}").status_code == 404

    # 22. Completed record remains available to administrators (never deleted).
    admin = make_client(app)
    assert login(admin, "admin@college.edu").status_code == 200
    r = admin.get("/admin/?section=history")
    assert r.status_code == 200 and b"Black leather wallet" in r.data
    assert admin.get(f"/items/{found.item_id}").status_code == 200
    assert Item.query.count() == 2

    # 23. Administrators can review history and reports.
    b.post(f"/claims/{claim.claim_id}/report", data={"reason": "Other", "details": "Testing reports"})
    assert Report.query.count() == 1
    r = admin.get("/admin/?section=reports")
    assert b"Testing reports" in r.data
    rep = Report.query.one()
    r = admin.post(f"/admin/reports/{rep.report_id}/resolve", data={"status": "reviewed", "note": "ok"},
                   follow_redirects=True)
    assert db.session.get(Report, rep.report_id).status == "reviewed"
    r = admin.get("/admin/")
    assert r.status_code == 200
    stats = re.findall(rb'<div class="stat[^"]*"><span>(\d+)</span>([^<]+)</div>', r.data)
    stats = {label.decode().strip(): int(n) for n, label in stats}
    assert stats["Completed returns"] == 1 and stats["Found reports"] == 1 and stats["Lost reports"] == 1
    assert admin.get(f"/claims/{claim.claim_id}/chat").status_code == 200   # admin can read chat
    assert admin.get("/admin/?section=audit").status_code == 200
    assert AuditLog.query.filter_by(action="item.returned").count() == 1
