"""Authorization, privacy, validation and moderation rules."""
import io
from datetime import date, timedelta

import pytest

from app import create_app, seed_locations
from conftest import PASSWORD, image_bytes, login, make_client, register
from extensions import db
from models import Claim, ClaimStatus, Item, ItemStatus, Message, User
from utils.security import reset_rate_limits

TODAY = date.today().isoformat()
LIBRARY = "Library"


def post_item(client, item_type="found", title="Blue water bottle", category="Bottle",
              location="Canteen", description="Steel bottle with a dent and a sticker.", **extra):
    data = {"type": item_type, "title": title, "category": category, "description": description,
            "event_date": TODAY, "location_name": location, "latitude": "", "longitude": ""}
    data.update(extra)
    return client.post("/items/new", data=data, content_type="multipart/form-data", follow_redirects=True)


def claim(client, item_id, proof="It has my name scratched near the cap and a cricket sticker."):
    return client.post(f"/items/{item_id}/claim", data={"proof": proof, "confirm": "yes"}, follow_redirects=True)


@pytest.fixture()
def people(app):
    clients = {}
    for key, name in [("a", "Student Alpha"), ("b", "Student Beta"), ("c", "Student Gamma")]:
        cl = make_client(app)
        register(cl, name, f"{key}@college.edu")
        clients[key] = cl
    admin = make_client(app)
    login(admin, "admin@college.edu")
    clients["admin"] = admin
    return clients


def test_outsider_cannot_see_claim_proof_or_chat(app, people):
    a, b, c = people["a"], people["b"], people["c"]
    post_item(a)
    item = Item.query.one()
    b.post(f"/items/{item.item_id}/claim", data={
        "proof": "It has my name scratched near the cap and a cricket sticker.", "confirm": "yes",
        "proof_photo": (image_bytes(), "p.jpg")}, content_type="multipart/form-data")
    cl = Claim.query.one()
    for url in (f"/claims/{cl.claim_id}/chat", f"/claims/{cl.claim_id}/proof-image",
                f"/claims/{cl.claim_id}/messages.json"):
        assert c.get(url).status_code == 404, url
    assert c.post(f"/claims/{cl.claim_id}/messages", json={"body": "hi"}).status_code == 404
    c.post(f"/claims/{cl.claim_id}/approve")
    assert db.session.get(Claim, cl.claim_id).status == ClaimStatus.PENDING
    # The proof text never appears on the public item page, even for the finder's page HTML.
    assert b"cricket sticker" not in c.get(f"/items/{item.item_id}").data
    # Proof photos live outside /static and are not reachable by file name.
    assert c.get(f"/static/../uploads/private/proofs/{cl.proof_image_path}").status_code == 404
    assert c.get(f"/media/items/{cl.proof_image_path}").status_code == 404


def test_claimant_cannot_approve_and_finder_cannot_claim_own(app, people):
    a, b = people["a"], people["b"]
    post_item(a)
    item = Item.query.one()
    r = claim(a, item.item_id)
    assert Claim.query.count() == 0
    claim(b, item.item_id)
    cl = Claim.query.one()
    b.post(f"/claims/{cl.claim_id}/approve")
    assert db.session.get(Claim, cl.claim_id).status == ClaimStatus.PENDING
    b.post(f"/claims/{cl.claim_id}/returned")
    assert db.session.get(Item, item.item_id).status == ItemStatus.CLAIM_REQUESTED


def test_lost_items_cannot_be_claimed(app, people):
    post_item(people["a"], item_type="lost")
    item = Item.query.one()
    assert people["b"].get(f"/items/{item.item_id}/claim").status_code == 404


def test_reject_returns_item_to_feed_and_competing_claims(app, people):
    a, b, c = people["a"], people["b"], people["c"]
    post_item(a)
    item = Item.query.one()
    claim(b, item.item_id)
    claim(c, item.item_id, proof="Mine: there's a cricket sticker and my roll number on tape.")
    assert Claim.query.count() == 2
    assert b"Blue water bottle" not in c.get("/feed").data          # CLAIM_REQUESTED is not public
    cb, cc = Claim.query.order_by(Claim.claim_id).all()

    a.post(f"/claims/{cb.claim_id}/reject", data={"note": "Description doesn't match"})
    assert db.session.get(Claim, cb.claim_id).status == ClaimStatus.REJECTED
    assert db.session.get(Item, item.item_id).status == ItemStatus.CLAIM_REQUESTED  # c still pending

    a.post(f"/claims/{cc.claim_id}/reject")
    assert db.session.get(Item, item.item_id).status == ItemStatus.ACTIVE
    assert b"Blue water bottle" in c.get("/feed").data
    assert b.post(f"/claims/{cb.claim_id}/messages", json={"body": "why?"}).status_code == 409


def test_approving_one_claim_closes_the_others(app, people):
    a, b, c = people["a"], people["b"], people["c"]
    post_item(a)
    item = Item.query.one()
    claim(b, item.item_id)
    claim(c, item.item_id, proof="Mine: there's a cricket sticker and my roll number on tape.")
    cb, cc = Claim.query.order_by(Claim.claim_id).all()
    a.post(f"/claims/{cc.claim_id}/approve")
    assert db.session.get(Claim, cc.claim_id).status == ClaimStatus.APPROVED
    assert db.session.get(Claim, cb.claim_id).status == ClaimStatus.REJECTED


def test_admin_routes_require_admin(app, people):
    assert people["a"].get("/admin/").status_code == 403
    assert make_client(app).get("/admin/").status_code == 302
    victim = User.query.filter_by(email="b@college.edu").one()
    people["a"].post(f"/admin/users/{victim.user_id}/block")
    assert db.session.get(User, victim.user_id).is_active


def test_block_logs_user_out_and_prevents_login(app, people):
    b = people["b"]
    victim = User.query.filter_by(email="b@college.edu").one()
    people["admin"].post(f"/admin/users/{victim.user_id}/block")
    assert not db.session.get(User, victim.user_id).is_active
    assert b.get("/feed").status_code == 302                 # session dropped
    r = login(b, "b@college.edu")
    assert b"blocked" in r.data
    people["admin"].post(f"/admin/users/{victim.user_id}/unblock")
    assert b"Live board" in login(b, "b@college.edu").data


def test_restricted_user_cannot_post(app, people):
    victim = User.query.filter_by(email="b@college.edu").one()
    people["admin"].post(f"/admin/users/{victim.user_id}/restrict")
    post_item(people["b"])
    assert Item.query.count() == 0
    people["admin"].post(f"/admin/users/{victim.user_id}/warn", data={"note": "Be nice"})
    assert db.session.get(User, victim.user_id).warning_count == 1


@pytest.mark.parametrize("filename,payload,expect", [
    ("virus.exe", b"MZ\x90\x00 not an image", b"PNG, JPG, JPEG or WEBP"),
    ("fake.jpg", b"<?php echo 'hi'; ?>", b"not a valid image"),
    ("photo.gif", b"GIF89a....", b"PNG, JPG, JPEG or WEBP"),
])
def test_bad_uploads_rejected(app, people, filename, payload, expect):
    r = post_item(people["a"], photo=(io.BytesIO(payload), filename))
    assert expect in r.data
    assert Item.query.count() == 0


def test_oversized_upload_rejected(app, people):
    big = io.BytesIO(b"\xff\xd8\xff" + b"0" * (6 * 1024 * 1024 + 10))
    r = post_item(people["a"], photo=(big, "big.jpg"))
    assert Item.query.count() == 0
    assert b"5 MB" in r.data


def test_png_and_webp_accepted(app, people):
    post_item(people["a"], title="Red keys", category="Keys", photo=(image_bytes("PNG"), "k.png"))
    post_item(people["a"], title="Grey bag", category="Bag", photo=(image_bytes("WEBP"), "b.webp"))
    assert Item.query.filter(Item.image_path.isnot(None)).count() == 2


def test_html_is_escaped(app, people):
    post_item(people["a"], title="<script>alert(1)</script> bag", category="Bag")
    r = people["b"].get("/feed")
    assert b"<script>alert(1)</script>" not in r.data
    assert b"&lt;script&gt;" in r.data


def test_sensitive_info_blocked_in_reports(app, people):
    r = post_item(people["a"], description="Call me on 9876543210 to collect it please")
    assert b"phone numbers" in r.data.lower() and Item.query.count() == 0


def test_validation_and_future_dates(app, people):
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    r = post_item(people["a"], event_date=tomorrow)
    assert b"future" in r.data and Item.query.count() == 0
    r = post_item(people["a"], category="Spaceship")
    assert Item.query.count() == 0
    r = post_item(people["a"], location="", location_custom="")
    assert Item.query.count() == 0
    r = post_item(people["a"], location="__custom__", location_custom="Bus stop near hostel",
                  latitude="12.8000", longitude="80.2262")
    assert Item.query.one().location_name == "Bus stop near hostel"
    r = post_item(people["a"], title="Far away bag", category="Bag", latitude="28.6", longitude="77.2")
    assert b"too far from campus" in r.data


def test_registration_rules(app):
    cl = make_client(app)
    assert register(cl, "A", "bad", "short").status_code == 400
    r = cl.post("/register", data={"name": "Student Alpha", "email": "student.a@college.edu",
                                   "password": "Campus123", "confirm_password": "Campus999"})
    assert b"don&#39;t match" in r.data or b"don't match" in r.data
    register(cl, "Student Alpha", "student.a@college.edu")
    cl2 = make_client(app)
    r = register(cl2, "Student Again", "STUDENT.A@college.edu")
    assert b"already exists" in r.data
    app.config["ALLOWED_EMAIL_DOMAINS"] = ["college.edu"]
    r = register(make_client(app), "Out Sider", "someone@gmail.com")
    assert b"Use your college email" in r.data


def test_login_wrong_password_and_open_redirect(app, people):
    cl = make_client(app)
    r = cl.post("/login", data={"email": "a@college.edu", "password": "nope12345"})
    assert r.status_code == 401
    r = cl.post("/login?next=//evil.example/x", data={"email": "a@college.edu", "password": PASSWORD})
    assert r.headers["Location"] == "/feed"


def test_chat_moderation(app, people):
    a, b = people["a"], people["b"]
    post_item(a)
    item = Item.query.one()
    claim(b, item.item_id)
    cl = Claim.query.one()
    url = f"/claims/{cl.claim_id}/messages"
    for bad in ["visit https://scam.example.com", "mail me at me@example.com",
                "you idiot", "transfer money first", "+91 98765 43210"]:
        assert b.post(url, json={"body": bad}).status_code == 400, bad
    r = b.post(url, json={"body": "Can you come to my house to drop it?"})
    assert r.status_code == 200
    assert Message.query.filter_by(is_flagged=True).count() == 1
    # Duplicate spam within two minutes is refused
    b.post(url, json={"body": "Is it still with you?"})
    assert b.post(url, json={"body": "Is it still with you?"}).status_code == 400
    # Flagged messages are visible to admins
    assert b"Mentions a personal address" in people["admin"].get("/admin/?section=reports").data


def test_admin_remove_and_restore(app, people):
    post_item(people["a"])
    item = Item.query.one()
    people["admin"].post(f"/admin/items/{item.item_id}/remove", data={"note": "Duplicate"})
    assert db.session.get(Item, item.item_id).status == ItemStatus.REMOVED
    assert b"Blue water bottle" not in people["b"].get("/feed").data
    people["admin"].post(f"/admin/items/{item.item_id}/restore")
    assert db.session.get(Item, item.item_id).status == ItemStatus.ACTIVE


def test_location_alone_is_not_a_match(app, people):
    post_item(people["a"], title="Silver laptop", category="Laptop", location=LIBRARY,
              description="Silver laptop with a cracked corner.")
    r = post_item(people["b"], item_type="lost", title="Brown umbrella", category="Other",
                  location=LIBRARY, description="Brown folding umbrella with a wooden handle.")
    assert b"POSSIBLE MATCH" not in r.data


def test_feed_search_and_filters(app, people):
    post_item(people["a"], title="Red keys", category="Keys", location="Hostel",
              description="Three keys on a red ring.")
    post_item(people["a"], item_type="lost", title="Physics notebook", category="Books",
              location=LIBRARY, description="Blue notebook full of physics notes.")
    b = people["b"]
    assert b"Red keys" in b.get("/feed?q=keys").data and b"Physics" not in b.get("/feed?q=keys").data
    assert b"Physics" in b.get("/feed?type=lost").data and b"Red keys" not in b.get("/feed?type=lost").data
    assert b"Red keys" in b.get("/feed?category=Keys").data
    assert b"Physics" in b.get("/feed", query_string={"location": LIBRARY}).data
    assert b"Red keys" not in b.get(f"/feed?to={(date.today() - timedelta(days=3)).isoformat()}").data
    assert b.get("/feed?q=%25%27--").status_code == 200


def test_owner_can_close_lost_report(app, people):
    post_item(people["a"], item_type="lost")
    item = Item.query.one()
    people["b"].post(f"/items/{item.item_id}/close", data={"reason": "recovered"})
    assert db.session.get(Item, item.item_id).status == ItemStatus.ACTIVE
    people["a"].post(f"/items/{item.item_id}/close", data={"reason": "recovered"})
    assert db.session.get(Item, item.item_id).status == ItemStatus.COMPLETED


def test_admin_locations_and_settings(app, people):
    adm = people["admin"]
    adm.post("/admin/locations", data={"name": "Auditorium", "latitude": "12.8001", "longitude": "80.2270",
                                       "is_handover_point": "on"})
    r = adm.get("/admin/?section=locations")
    assert b"Auditorium" in r.data
    adm.post("/admin/settings", data={"campus_name": "St. Example College", "campus_lat": "12.80",
                                      "campus_lng": "80.226", "campus_zoom": "17",
                                      "match_threshold": "50", "nearby_meters": "200"})
    assert b"St. Example College" in people["a"].get("/feed").data
    r = adm.post("/admin/settings", data={"campus_zoom": "40"}, follow_redirects=True)
    assert b"Zoom must be between" in r.data


def test_csrf_enforced_outside_tests(tmp_path):
    app = create_app("testing")
    app.config.update(WTF_CSRF_ENABLED=True, UPLOAD_ROOT=str(tmp_path))
    with app.app_context():
        db.create_all()
        seed_locations()
        cl = app.test_client()
        r = cl.post("/register", data={"name": "No Token", "email": "x@college.edu",
                                       "password": "Campus123", "confirm_password": "Campus123"})
        assert r.status_code == 303
        assert User.query.count() == 0
        db.drop_all()


def test_login_rate_limit(app):
    app.config["RATELIMIT_ENABLED"] = True
    reset_rate_limits()
    cl = make_client(app)
    codes = [cl.post("/login", data={"email": "x@college.edu", "password": "wrong123"}).status_code
             for _ in range(12)]
    assert codes[:10] == [401] * 10 and codes[-1] == 303


def test_security_headers(app):
    r = make_client(app).get("/")
    assert "default-src 'self'" in r.headers["Content-Security-Policy"]
    assert r.headers["X-Frame-Options"] == "DENY"
    assert "HttpOnly" in (make_client(app).post("/login", data={"email": "admin@college.edu",
                                                                 "password": PASSWORD}).headers.get("Set-Cookie") or "")


def test_first_run_setup_creates_admin(app):
    User.query.delete()
    db.session.commit()
    db.session.expunge_all()
    app.config["TESTING"] = False          # enable the first-run redirect
    cl = make_client(app)
    r = cl.get("/feed")
    assert r.status_code == 302 and r.headers["Location"].endswith("/setup")
    assert cl.get("/register").headers["Location"].endswith("/setup")
    r = cl.post("/setup", data={"name": "Campus Admin", "email": "admin@college.edu",
                                "password": "Campus123", "confirm_password": "Campus123"})
    assert r.status_code == 302 and "/admin" in r.headers["Location"]
    admin = User.query.one()
    assert admin.is_admin and admin.check_password("Campus123")
    assert cl.get("/admin/").status_code == 200
    # Setup can't be used again once an admin exists.
    assert make_client(app).get("/setup").headers["Location"].endswith("/login")
    app.config["TESTING"] = True


def test_default_campus_locations_loaded(app):
    from models import CampusLocation
    names = {loc.name for loc in CampusLocation.query.all()}
    assert "Library" in names and "Main Block" in names
    lib = CampusLocation.query.filter_by(name="Library").one()
    assert 12.79 < lib.latitude < 12.81 and 80.22 < lib.longitude < 80.24


def test_gmail_can_register_by_default(app):
    cl = make_client(app)
    r = register(cl, "Gmail User", "someone.student@gmail.com")
    assert b"Welcome, Gmail" in r.data
    assert User.query.filter_by(email="someone.student@gmail.com").one()
    assert b"Gmail works" in make_client(app).get("/register").data
