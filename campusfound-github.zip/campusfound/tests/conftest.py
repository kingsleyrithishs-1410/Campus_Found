import io
import os
import sys
import tempfile

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["FLASK_CONFIG"] = "testing"
os.environ.setdefault("UPLOAD_ROOT", tempfile.mkdtemp(prefix="lf-uploads-"))

from PIL import Image  # noqa: E402

from app import create_app, seed_locations  # noqa: E402
from extensions import db  # noqa: E402
from models import Role, User  # noqa: E402
from utils.security import reset_rate_limits  # noqa: E402

PASSWORD = "Campus123"


@pytest.fixture()
def app(tmp_path):
    app = create_app("testing")
    app.config["UPLOAD_ROOT"] = str(tmp_path / "uploads")
    with app.app_context():
        db.create_all()
        seed_locations()
        admin = User(name="Campus Admin", email="admin@college.edu", role=Role.ADMIN, email_verified=True)
        admin.set_password(PASSWORD)
        db.session.add(admin)
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()
    reset_rate_limits()


def make_client(app):
    return app.test_client()


def register(client, name, email, password=PASSWORD):
    return client.post("/register", data={
        "name": name, "email": email, "password": password, "confirm_password": password,
    }, follow_redirects=True)


def login(client, email, password=PASSWORD):
    return client.post("/login", data={"email": email, "password": password}, follow_redirects=True)


def image_bytes(fmt="JPEG", size=(640, 480), color=(20, 20, 20), with_gps=False):
    img = Image.new("RGB", size, color)
    buf = io.BytesIO()
    kwargs = {}
    if with_gps and fmt == "JPEG":
        exif = Image.Exif()
        exif[0x010F] = "TestCam"                  # Make
        exif[0x8825] = {1: "N", 2: (12.0, 58.0, 17.0), 3: "E", 4: (77.0, 35.0, 40.0)}  # GPSInfo
        kwargs["exif"] = exif.tobytes()
    img.save(buf, format=fmt, **kwargs)
    buf.seek(0)
    return buf
