"""Jinja filters and context helpers."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from flask import current_app


def _tz():
    try:
        return ZoneInfo(current_app.config.get("DISPLAY_TIMEZONE") or "UTC")
    except ZoneInfoNotFoundError:
        return timezone.utc


def local_time(value, fmt="%d %b %Y, %H:%M"):
    """Format a naive-UTC datetime in the campus time zone."""
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.replace(tzinfo=timezone.utc).astimezone(_tz()).strftime(fmt)
    return value.strftime(fmt)


def nice_date(value):
    if value is None:
        return ""
    return f"{value.day} {value.strftime('%B %Y')}"


def time_ago(value):
    if value is None:
        return ""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    seconds = int((now - value).total_seconds())
    if seconds < 60:
        return "just now"
    if seconds < 3600:
        return f"{seconds // 60} min ago"
    if seconds < 86400:
        return f"{seconds // 3600} h ago"
    days = seconds // 86400
    if days < 7:
        return f"{days} day{'s' if days != 1 else ''} ago"
    return local_time(value, "%d %b %Y")


def register(app):
    app.add_template_filter(local_time, "local_time")
    app.add_template_filter(nice_date, "nice_date")
    app.add_template_filter(time_ago, "time_ago")
