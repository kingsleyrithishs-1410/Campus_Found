"""Who may see what."""
from models import ItemStatus


def can_view_item(item, user):
    """Open reports are visible to every logged-in user. Finished, closed or
    removed reports are only visible to the reporter, its claimants and admins."""
    if user is None:
        return False
    if item.status in ItemStatus.OPEN:
        return True
    if user.is_admin or item.owner_id == user.user_id:
        return True
    return item.claims.filter_by(claimant_id=user.user_id).first() is not None
