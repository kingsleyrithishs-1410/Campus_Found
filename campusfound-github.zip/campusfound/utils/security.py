"""Authentication helpers, access decorators and a small rate limiter."""
import threading
import time
from collections import defaultdict, deque
from functools import wraps
from urllib.parse import urlparse

from flask import abort, current_app, flash, g, redirect, request, url_for


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.get("user") is None:
            flash("Log in to continue.", "info")
            return redirect(url_for("auth.login", next=request.full_path))
        return view(*args, **kwargs)

    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if not g.user.is_admin:
            abort(403)
        return view(*args, **kwargs)

    return wrapped


def not_restricted(view):
    """Restricted users can read but not post reports, claims or messages."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.get("user") is not None and g.user.is_restricted and request.method == "POST":
            flash("Your account is restricted by an administrator. You can browse, but not post.", "error")
            return redirect(request.referrer or url_for("main.feed"))
        return view(*args, **kwargs)

    return wrapped


def is_safe_next(target):
    """Only allow redirects to paths on this site (prevents open redirects)."""
    if not target:
        return False
    parsed = urlparse(target)
    return not parsed.scheme and not parsed.netloc and target.startswith("/") and not target.startswith("//")


# --------------------------------------------------------------------------
# In-memory rate limiter. Fine for a single process; for several workers use
# a shared store (e.g. Flask-Limiter with Redis).
# --------------------------------------------------------------------------
_hits = defaultdict(deque)
_lock = threading.Lock()


def _limited(key, limit, period):
    now = time.monotonic()
    with _lock:
        bucket = _hits[key]
        while bucket and now - bucket[0] > period:
            bucket.popleft()
        if len(bucket) >= limit:
            return True
        bucket.append(now)
        return False


def rate_limit(limit, period, scope="ip", methods=("POST",)):
    """Allow ``limit`` requests per ``period`` seconds per IP (or per user)."""

    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if current_app.config.get("RATELIMIT_ENABLED") and request.method in methods:
                who = request.remote_addr or "unknown"
                if scope == "user" and g.get("user") is not None:
                    who = f"user:{g.user.user_id}"
                if _limited(f"{view.__name__}:{who}", limit, period):
                    if request.accept_mimetypes.best == "application/json" or request.is_json:
                        return {"ok": False, "error": "Too many requests. Wait a moment and try again."}, 429
                    flash("Too many attempts. Wait a moment and try again.", "error")
                    return redirect(request.referrer or url_for("main.feed")), 303
            return view(*args, **kwargs)

        return wrapped

    return decorator


def reset_rate_limits():
    with _lock:
        _hits.clear()
