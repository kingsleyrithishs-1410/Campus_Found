"""Ownership claims: proof submission and the finder's decisions."""
import os

from flask import (Blueprint, abort, flash, g, redirect, render_template, request,
                   send_from_directory, url_for)

from extensions import db
from models import Claim, Item, ItemStatus, ItemType
from services.matching import score_pair
from services.moderation import check_report_text
from services.settings import get_setting
from services.uploads import UploadError, delete_image, has_file, proof_upload_dir, save_image
from services.workflow import (WorkflowError, add_proof, approve_claim, mark_returned,
                               reject_claim, submit_claim)
from utils.security import login_required, not_restricted, rate_limit

bp = Blueprint("claims", __name__)


def _get_claim_for(user, claim_id):
    claim = db.session.get(Claim, claim_id)
    if claim is None or not claim.can_view(user):
        abort(404)       # 404 rather than 403: don't reveal that the claim exists
    return claim


@bp.route("/items/<int:item_id>/claim", methods=["GET", "POST"])
@login_required
@not_restricted
@rate_limit(10, 3600, scope="user")
def new_claim(item_id):
    item = db.session.get(Item, item_id)
    if item is None or item.item_type != ItemType.FOUND or item.status not in ItemStatus.OPEN:
        abort(404)
    if item.owner_id == g.user.user_id:
        flash("You reported this item, so you can't claim it.", "error")
        return redirect(url_for("items.detail", item_id=item_id))
    existing = Claim.query.filter_by(item_id=item_id, claimant_id=g.user.user_id).first()
    if existing:
        flash("You've already claimed this item. Continue in the claim conversation.", "info")
        return redirect(url_for("chat.conversation", claim_id=existing.claim_id))
    if item.status not in (ItemStatus.ACTIVE, ItemStatus.CLAIM_REQUESTED):
        flash("This item is no longer accepting claims.", "error")
        return redirect(url_for("items.detail", item_id=item_id))

    my_lost = (Item.query.filter(Item.owner_id == g.user.user_id, Item.item_type == ItemType.LOST,
                                 Item.status == ItemStatus.ACTIVE)
               .order_by(Item.created_at.desc()).all())
    # Pre-select the claimant's lost report that best matches this found item.
    form = {}
    if my_lost:
        scored = sorted(((score_pair(lost, item).score, lost) for lost in my_lost),
                        key=lambda pair: pair[0], reverse=True)
        if scored[0][0] >= get_setting("match_threshold"):
            form = {"lost_item_id": scored[0][1].item_id}
    if request.method == "POST":
        form = request.form
        proof = form.get("proof", "").strip()
        serial = " ".join(form.get("serial_number", "").split())[:120]
        purchase = " ".join(form.get("purchase_info", "").split())[:255]
        marks = form.get("unique_marks", "").strip()[:2000]
        lost_id = form.get("lost_item_id", type=int)
        errors = []
        if not 20 <= len(proof) <= 2000:
            errors.append("Describe the item in your own words (at least 20 characters). "
                          "Mention details only the owner would know.")
        if form.get("confirm") != "yes":
            errors.append("Confirm that the information is true.")
        problem = check_report_text(proof + " " + marks)
        if problem and "phone" not in problem.lower():   # serials may look like numbers
            errors.append(problem)

        photo = request.files.get("proof_photo")
        image_name = None
        if not errors and has_file(photo):
            try:
                image_name = save_image(photo, private=True)
            except UploadError as exc:
                errors.append(str(exc))

        if not errors:
            lost_item = None
            if lost_id:
                lost_item = next((i for i in my_lost if i.item_id == lost_id), None)
            try:
                claim = submit_claim(item, g.user, proof, serial, purchase, marks, image_name, lost_item)
                db.session.commit()
            except WorkflowError as exc:
                db.session.rollback()
                delete_image(image_name, private=True)
                errors.append(str(exc))
            else:
                flash("Your claim and private proof were sent to the finder. "
                      "Use this conversation to arrange the return.", "success")
                return redirect(url_for("chat.conversation", claim_id=claim.claim_id))
        for e in errors:
            flash(e, "error")
        return render_template("claim.html", item=item, my_lost=my_lost, form=form), 400

    return render_template("claim.html", item=item, my_lost=my_lost, form=form)


@bp.route("/claims/<int:claim_id>/proof-image")
@login_required
def proof_image(claim_id):
    """Private proof photo: only the claimant, the finder and admins."""
    claim = _get_claim_for(g.user, claim_id)
    if not claim.proof_image_path:
        abort(404)
    response = send_from_directory(proof_upload_dir(), os.path.basename(claim.proof_image_path))
    response.headers["Cache-Control"] = "private, no-store"
    response.headers["X-Robots-Tag"] = "noindex"
    return response


def _decision(claim_id, action, success_message):
    claim = _get_claim_for(g.user, claim_id)
    try:
        action(claim)
        db.session.commit()
        flash(success_message, "success")
    except WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return redirect(url_for("chat.conversation", claim_id=claim_id))


@bp.route("/claims/<int:claim_id>/approve", methods=["POST"])
@login_required
def approve(claim_id):
    return _decision(claim_id, lambda c: approve_claim(c, g.user),
                     "Claim approved. Agree on a safe campus hand-over point.")


@bp.route("/claims/<int:claim_id>/reject", methods=["POST"])
@login_required
def reject(claim_id):
    note = request.form.get("note", "")
    return _decision(claim_id, lambda c: reject_claim(c, g.user, note),
                     "Claim rejected. The item is back in the public feed if no other claims are open.")


@bp.route("/claims/<int:claim_id>/returned", methods=["POST"])
@login_required
def returned(claim_id):
    return _decision(claim_id, lambda c: mark_returned(c, g.user),
                     "Marked as returned. The case is completed and removed from the public feed.")


@bp.route("/claims/<int:claim_id>/add-proof", methods=["POST"])
@login_required
@not_restricted
def more_proof(claim_id):
    text = request.form.get("extra_proof", "")
    return _decision(claim_id, lambda c: add_proof(c, g.user, text), "Additional proof added.")
