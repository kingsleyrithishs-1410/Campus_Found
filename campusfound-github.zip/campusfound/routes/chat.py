"""Protected, item-specific conversations.

A conversation exists only for a claim and is visible only to the finder, the
claimant and administrators. Messages are checked by services.moderation.
New messages are fetched by polling (/messages.json); the endpoints are
shaped so a WebSocket transport can replace polling later.
"""
from datetime import timedelta

from flask import (Blueprint, abort, flash, g, jsonify, redirect, render_template,
                   request, url_for)

from extensions import db
from models import (REPORT_REASONS, CampusLocation, Claim, ClaimStatus, Message, Report,
                    ReportStatus, utcnow)
from services.audit import audit
from services.moderation import check_message
from services.notifications import notify_new_message
from utils.security import login_required, rate_limit
from utils.template_helpers import local_time

bp = Blueprint("chat", __name__, url_prefix="/claims")

CLAIMANT_SUGGESTIONS = [
    "Where exactly was the item found?",
    "Can you describe the condition of the item?",
    "I can provide additional ownership proof.",
    "What identifying feature should I confirm?",
    "What is the preferred safe handover point?",
    "I would like to arrange the return.",
]

FINDER_SUGGESTIONS = [
    "Can you describe a unique mark or feature on the item?",
    "What was inside or attached to the item?",
    "Where and when do you think you lost it?",
    "What is the preferred safe handover point?",
    "Can we meet at the campus security desk?",
    "I would like to arrange the return.",
]

APPROVED_EXTRA = [
    "Can we meet at the Main Block entrance?",
    "I'm available today between classes.",
    "Please bring your college ID for the hand-over.",
]


def suggestions_for(claim, user):
    if user.user_id == claim.claimant_id:
        base = list(CLAIMANT_SUGGESTIONS)
    elif user.user_id == claim.item.owner_id:
        base = list(FINDER_SUGGESTIONS)
    else:
        return []
    if claim.status == ClaimStatus.APPROVED:
        base = APPROVED_EXTRA + [s for s in base if "handover" in s.lower() or "return" in s.lower()]
    return base


def _claim_or_404(claim_id):
    claim = db.session.get(Claim, claim_id)
    if claim is None or not claim.can_view(g.user):
        abort(404)
    return claim


def serialize(msg, viewer):
    return {
        "id": msg.message_id,
        "body": msg.body,
        "system": msg.is_system,
        "mine": msg.sender_id == viewer.user_id,
        "sender": "System" if msg.is_system else msg.sender.public_name,
        "suggestion": msg.is_suggestion,
        "flagged": msg.is_flagged if viewer.is_admin else False,
        "time": local_time(msg.created_at, "%d %b, %H:%M"),
    }


@bp.route("/<int:claim_id>/chat")
@login_required
def conversation(claim_id):
    claim = _claim_or_404(claim_id)
    item = claim.item
    messages = claim.messages.all()
    role = ("claimant" if g.user.user_id == claim.claimant_id
            else "finder" if g.user.user_id == item.owner_id else "admin")
    already_reported = Report.query.filter_by(
        claim_id=claim.claim_id, reporter_id=g.user.user_id, status=ReportStatus.OPEN
    ).first() is not None
    return render_template(
        "chat.html", claim=claim, item=item, messages=messages, role=role,
        suggestions=suggestions_for(claim, g.user), report_reasons=REPORT_REASONS,
        can_send=claim.chat_open and role != "admin" and not g.user.is_restricted,
        already_reported=already_reported,
        handover_points=CampusLocation.query.filter_by(is_handover_point=True, is_active=True)
        .order_by(CampusLocation.name).all(),
    )


@bp.route("/<int:claim_id>/messages", methods=["POST"])
@login_required
@rate_limit(12, 60, scope="user")
def send(claim_id):
    claim = _claim_or_404(claim_id)
    wants_json = request.is_json or request.accept_mimetypes.best == "application/json"
    payload = request.get_json(silent=True) or request.form
    body = (payload.get("body") or "").strip()

    def fail(message, status=400):
        if wants_json:
            return jsonify({"ok": False, "error": message}), status
        flash(message, "error")
        return redirect(url_for("chat.conversation", claim_id=claim_id))

    if not claim.is_participant(g.user):
        return fail("Only the finder and the claimant can send messages here.", 403)
    if g.user.is_restricted:
        return fail("Your account is restricted. You can't send messages.", 403)
    if not claim.chat_open:
        return fail("This conversation is closed.", 409)

    verdict = check_message(body)
    if not verdict.allowed:
        return fail(verdict.reason)

    last = (Message.query.filter_by(claim_id=claim.claim_id, sender_id=g.user.user_id)
            .order_by(Message.message_id.desc()).first())
    if last and last.body == body and utcnow() - last.created_at < timedelta(minutes=2):
        return fail("You just sent that message.")

    msg = Message(
        claim_id=claim.claim_id, sender_id=g.user.user_id, body=body,
        # A message counts as a suggestion only if it was sent unedited.
        is_suggestion=body in suggestions_for(claim, g.user),
        is_flagged=verdict.flagged, flag_reason=verdict.reason or None,
    )
    db.session.add(msg)
    notify_new_message(claim, g.user, url_for("chat.conversation", claim_id=claim_id))
    db.session.commit()
    if wants_json:
        return jsonify({"ok": True, "message": serialize(msg, g.user)})
    return redirect(url_for("chat.conversation", claim_id=claim_id) + "#composer")


@bp.route("/<int:claim_id>/messages.json")
@login_required
def poll(claim_id):
    claim = _claim_or_404(claim_id)
    after = request.args.get("after", 0, type=int)
    msgs = claim.messages.filter(Message.message_id > after).limit(100).all()
    return jsonify({
        "ok": True,
        "status": claim.status,
        "open": claim.chat_open,
        "messages": [serialize(m, g.user) for m in msgs],
    })


@bp.route("/<int:claim_id>/report", methods=["POST"])
@login_required
@rate_limit(10, 3600, scope="user")
def report(claim_id):
    claim = _claim_or_404(claim_id)
    if not claim.is_participant(g.user):
        abort(403)
    reason = request.form.get("reason", "")
    details = request.form.get("details", "").strip()[:1000]
    if reason not in REPORT_REASONS:
        flash("Choose a reason for the report.", "error")
        return redirect(url_for("chat.conversation", claim_id=claim_id))
    if Report.query.filter_by(claim_id=claim_id, reporter_id=g.user.user_id,
                              status=ReportStatus.OPEN).first():
        flash("You've already reported this conversation. An administrator will review it.", "info")
        return redirect(url_for("chat.conversation", claim_id=claim_id))
    other_id = claim.item.owner_id if g.user.user_id == claim.claimant_id else claim.claimant_id
    rep = Report(item_id=claim.item_id, claim_id=claim.claim_id, reporter_id=g.user.user_id,
                 reported_user_id=other_id, reason=reason, details=details or None)
    db.session.add(rep)
    db.session.flush()
    audit("report.created", "report", rep.report_id, f"claim {claim_id}: {reason}")
    db.session.commit()
    flash("Conversation reported. An administrator will review it.", "success")
    return redirect(url_for("chat.conversation", claim_id=claim_id))
