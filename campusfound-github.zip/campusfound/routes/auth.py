"""Registration, login, logout and email verification."""
import re

from flask import (Blueprint, current_app, flash, g, redirect, render_template,
                   request, session, url_for)

from extensions import db
from models import Role, User, utcnow
from services.audit import audit
from services.mailer import make_verification_token, read_verification_token, send_email
from utils.security import is_safe_next, rate_limit

bp = Blueprint("auth", __name__)

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[^\W\d_][\w .'-]*$", re.UNICODE)


def validate_password(password):
    if len(password) < 8:
        return "Password must be at least 8 characters."
    if len(password) > 128:
        return "Password must be at most 128 characters."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must contain at least one letter and one number."
    return None


def email_domain_allowed(email):
    domains = current_app.config["ALLOWED_EMAIL_DOMAINS"]
    if not domains:
        return True
    domain = email.rsplit("@", 1)[-1].lower()
    return any(domain == d or domain.endswith("." + d) for d in domains)


def start_session(user):
    session.clear()             # prevents session fixation
    session.permanent = True
    session["user_id"] = user.user_id
    user.last_login_at = utcnow()


def send_verification(user):
    link = url_for("auth.verify_email", token=make_verification_token(user), _external=True)
    send_email(
        user.email,
        "Confirm your campus Lost & Found account",
        f"Hi {user.name},\n\nConfirm your email address by opening this link:\n{link}\n\n"
        "The link expires in 3 days. If you didn't create an account, ignore this email.",
    )


@bp.route("/register", methods=["GET", "POST"])
@rate_limit(10, 3600)
def register():
    if g.user:
        return redirect(url_for("main.feed"))
    form = {"name": "", "email": ""}
    if request.method == "POST":
        name = " ".join(request.form.get("name", "").split())
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        form = {"name": name, "email": email}
        errors = []

        if not (2 <= len(name) <= 120) or not NAME_RE.match(name):
            errors.append("Enter your full name (letters, spaces, apostrophes or hyphens).")
        if not EMAIL_RE.match(email) or len(email) > 255:
            errors.append("Enter a valid email address.")
        elif not email_domain_allowed(email):
            allowed = ", ".join("@" + d for d in current_app.config["ALLOWED_EMAIL_DOMAINS"])
            errors.append(f"Use your college email ({allowed}).")
        pw_error = validate_password(password)
        if pw_error:
            errors.append(pw_error)
        if password != confirm:
            errors.append("The two passwords don't match.")
        if not errors and User.query.filter_by(email=email).first():
            errors.append("An account with this email already exists. Log in instead.")

        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("register.html", form=form), 400

        user = User(name=name, email=email, role=Role.USER)
        user.set_password(password)
        user.email_verified = not current_app.config["EMAIL_VERIFICATION_REQUIRED"]
        db.session.add(user)
        db.session.flush()
        audit("user.registered", "user", user.user_id, actor=user)
        db.session.commit()

        if current_app.config["EMAIL_VERIFICATION_REQUIRED"]:
            send_verification(user)
            flash("Account created. Check your email for a confirmation link, then log in.", "success")
            return redirect(url_for("auth.login"))

        start_session(user)
        db.session.commit()
        flash(f"Welcome, {user.name.split()[0]}! Your account is ready.", "success")
        return redirect(url_for("main.feed"))
    return render_template("register.html", form=form)


@bp.route("/login", methods=["GET", "POST"])
@rate_limit(10, 300)
def login():
    if g.user:
        return redirect(url_for("main.feed"))
    email = ""
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter_by(email=email).first()
        # Same message whether the email or the password is wrong.
        if user is None or not user.check_password(password):
            audit("auth.login_failed", "user", user.user_id if user else None, email[:120])
            db.session.commit()
            flash("Email or password is incorrect.", "error")
            return render_template("login.html", email=email), 401
        if not user.is_active:
            flash("This account has been blocked by an administrator. Contact the campus office.", "error")
            return render_template("login.html", email=email), 403
        if not user.email_verified:
            send_verification(user)
            flash("Confirm your email address first. We've sent a new confirmation link.", "info")
            return render_template("login.html", email=email), 403

        start_session(user)
        audit("auth.login", "user", user.user_id, actor=user)
        db.session.commit()
        next_url = request.args.get("next")
        return redirect(next_url if is_safe_next(next_url) else url_for("main.feed"))
    return render_template("login.html", email=email)


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have logged out.", "info")
    return redirect(url_for("main.index"))


@bp.route("/verify/<token>")
def verify_email(token):
    data = read_verification_token(token)
    user = db.session.get(User, data["uid"]) if data else None
    if user is None or user.email != data.get("email"):
        flash("That confirmation link is invalid or has expired. Log in to get a new one.", "error")
        return redirect(url_for("auth.login"))
    user.email_verified = True
    audit("user.email_verified", "user", user.user_id, actor=user)
    db.session.commit()
    flash("Email confirmed. You can log in now.", "success")
    return redirect(url_for("auth.login"))


@bp.route("/setup", methods=["GET", "POST"])
@rate_limit(10, 3600)
def setup():
    """First run only: create the first administrator account."""
    if User.query.filter_by(role=Role.ADMIN).first() is not None:
        return redirect(url_for("auth.login"))
    form = {"name": "", "email": ""}
    if request.method == "POST":
        name = " ".join(request.form.get("name", "").split())
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        form = {"name": name, "email": email}
        errors = []
        if not (2 <= len(name) <= 120) or not NAME_RE.match(name):
            errors.append("Enter the administrator's full name.")
        if not EMAIL_RE.match(email):
            errors.append("Enter a valid email address.")
        pw_error = validate_password(password)
        if pw_error:
            errors.append(pw_error)
        if password != confirm:
            errors.append("The two passwords don't match.")
        existing = User.query.filter_by(email=email).first()
        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("setup.html", form=form), 400
        if existing:
            existing.role = Role.ADMIN
            existing.set_password(password)
            user = existing
        else:
            user = User(name=name, email=email, role=Role.ADMIN, email_verified=True)
            user.set_password(password)
            db.session.add(user)
        db.session.flush()
        audit("admin.setup", "user", user.user_id, actor=user)
        start_session(user)
        db.session.commit()
        current_app.config["_HAS_ADMIN"] = True
        flash("Administrator account created. campusfound is ready for your campus.", "success")
        return redirect(url_for("admin.dashboard"))
    return render_template("setup.html", form=form)
