"""Administrator dashboard and moderation actions."""
from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for
from sqlalchemy import or_
from sqlalchemy.exc import IntegrityError

from extensions import db
from models import (AuditLog, CampusLocation, Claim, ClaimStatus, Item, ItemStatus,
                    ItemType, Message, Report, ReportStatus, Role, User, utcnow)
from services.audit import audit
from services.notifications import Kind, notify
from services.settings import SETTINGS_SCHEMA, all_settings, set_setting
from services.workflow import WorkflowError, admin_remove_item, admin_restore_item, reject_claim
from utils.security import admin_required

bp = Blueprint("admin", __name__, url_prefix="/admin")

SECTIONS = ["overview", "users", "items", "claims", "reports", "history",
            "locations", "settings", "audit"]
PER_PAGE = 25


def _like(term):
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


def dashboard_stats():
    return {
        "total_users": User.query.count(),
        "active_reports": Item.query.filter_by(status=ItemStatus.ACTIVE).count(),
        "lost_reports": Item.query.filter_by(item_type=ItemType.LOST).count(),
        "found_reports": Item.query.filter_by(item_type=ItemType.FOUND).count(),
        "pending_claims": Claim.query.filter_by(status=ClaimStatus.PENDING).count(),
        "completed_returns": Claim.query.filter_by(status=ClaimStatus.RETURNED).count(),
        "flagged_reports": Report.query.filter_by(status=ReportStatus.OPEN).count(),
        "flagged_messages": Message.query.filter_by(is_flagged=True).count(),
        "blocked_users": User.query.filter_by(is_active=False).count(),
    }


@bp.route("/")
@admin_required
def dashboard():
    section = request.args.get("section", "overview")
    if section not in SECTIONS:
        abort(404)
    q = (request.args.get("q") or "").strip()[:100]
    status = request.args.get("status", "")
    item_type = request.args.get("type", "")
    page = max(request.args.get("page", 1, type=int), 1)
    ctx = {"section": section, "q": q, "status": status, "item_type": item_type,
           "stats": dashboard_stats(), "ItemStatus": ItemStatus, "ClaimStatus": ClaimStatus,
           "ReportStatus": ReportStatus}

    if section == "overview":
        ctx["recent_reports"] = (Report.query.filter_by(status=ReportStatus.OPEN)
                                 .order_by(Report.created_at.desc()).limit(5).all())
        ctx["recent_items"] = Item.query.order_by(Item.created_at.desc()).limit(6).all()
        ctx["flagged_messages"] = (Message.query.filter_by(is_flagged=True)
                                   .order_by(Message.created_at.desc()).limit(5).all())
        ctx["by_category"] = (db.session.query(Item.category, db.func.count(Item.item_id))
                              .group_by(Item.category).order_by(db.func.count(Item.item_id).desc()).all())

    elif section == "users":
        query = User.query
        if q:
            query = query.filter(or_(User.name.ilike(_like(q), escape="\\"),
                                     User.email.ilike(_like(q), escape="\\")))
        if status == "blocked":
            query = query.filter_by(is_active=False)
        elif status == "restricted":
            query = query.filter_by(is_restricted=True)
        elif status == "admin":
            query = query.filter_by(role=Role.ADMIN)
        ctx["page_obj"] = (query.order_by(User.created_at.desc())).paginate(page=page,
                                      per_page=PER_PAGE, error_out=False)

    elif section in ("items", "history"):
        query = Item.query
        if section == "history":
            query = query.filter(Item.status.in_((ItemStatus.COMPLETED, ItemStatus.CLOSED,
                                                  ItemStatus.REMOVED)))
        elif status in ItemStatus.ALL:
            query = query.filter_by(status=status)
        if item_type in ItemType.ALL:
            query = query.filter_by(item_type=item_type)
        if q:
            query = query.filter(or_(Item.title.ilike(_like(q), escape="\\"),
                                     Item.location_name.ilike(_like(q), escape="\\")))
        order = Item.completed_at.desc() if section == "history" else Item.created_at.desc()
        ctx["page_obj"] = (query.order_by(order)).paginate(page=page,
                                      per_page=PER_PAGE, error_out=False)

    elif section == "claims":
        query = Claim.query
        if status in ClaimStatus.ALL:
            query = query.filter_by(status=status)
        ctx["page_obj"] = (query.order_by(Claim.created_at.desc())).paginate(page=page,
                                      per_page=PER_PAGE, error_out=False)

    elif section == "reports":
        query = Report.query
        if status in ReportStatus.ALL:
            query = query.filter_by(status=status)
        ctx["page_obj"] = (query.order_by(Report.created_at.desc())).paginate(page=page,
                                      per_page=PER_PAGE, error_out=False)
        ctx["flagged_messages"] = (Message.query.filter_by(is_flagged=True)
                                   .order_by(Message.created_at.desc()).limit(20).all())

    elif section == "locations":
        ctx["locations"] = CampusLocation.query.order_by(CampusLocation.name).all()
        ctx["locations_json"] = [loc.to_dict() for loc in ctx["locations"]]

    elif section == "settings":
        ctx["settings"] = all_settings()
        ctx["schema"] = SETTINGS_SCHEMA

    elif section == "audit":
        ctx["page_obj"] = (AuditLog.query.order_by(AuditLog.created_at.desc())).paginate(page=page, per_page=50, error_out=False)

    return render_template("admin.html", **ctx)


def _back(section):
    target = request.form.get("next") or url_for("admin.dashboard", section=section)
    if not target.startswith("/admin"):
        target = url_for("admin.dashboard", section=section)
    return redirect(target)


# ---------------------------------------------------------------- users ---
def apply_user_action(user, action, note=None):
    """Shared by the Users table and report resolution."""
    if user.user_id == g.user.user_id and action in ("block", "restrict", "demote"):
        raise WorkflowError("You can't apply that action to your own account.")
    note = (note or "").strip()[:200]
    if action == "block":
        user.is_active = False
        msg = "blocked"
    elif action == "unblock":
        user.is_active = True
        msg = "unblocked"
    elif action == "restrict":
        user.is_restricted = True
        notify(user, Kind.ADMIN_WARNING,
               "Your account is restricted: you can browse but not post. " + (note or "Contact the campus office."))
        msg = "restricted"
    elif action == "unrestrict":
        user.is_restricted = False
        notify(user, Kind.ADMIN_NOTICE, "Your account restriction was lifted.")
        msg = "unrestricted"
    elif action == "warn":
        user.warning_count += 1
        notify(user, Kind.ADMIN_WARNING,
               "Warning from an administrator: " + (note or "Please follow the campus Lost & Found safety rules."))
        msg = "warned"
    else:
        raise WorkflowError("Unknown action.")
    audit(f"user.{action}", "user", user.user_id, note)
    return msg


@bp.route("/users/<int:user_id>/<action>", methods=["POST"])
@admin_required
def user_action(user_id, action):
    user = db.session.get(User, user_id)
    if user is None:
        abort(404)
    try:
        msg = apply_user_action(user, action, request.form.get("note"))
        db.session.commit()
        flash(f"{user.name} was {msg}.", "success")
    except WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return _back("users")


# ---------------------------------------------------------------- items ---
@bp.route("/items/<int:item_id>/<action>", methods=["POST"])
@admin_required
def item_action(item_id, action):
    item = db.session.get(Item, item_id)
    if item is None:
        abort(404)
    try:
        if action == "remove":
            admin_remove_item(item, g.user, request.form.get("note", "").strip()[:200])
            flash(f"\"{item.title}\" was removed from the feed. The record is kept.", "success")
        elif action == "restore":
            admin_restore_item(item, g.user)
            flash(f"\"{item.title}\" was restored to the feed.", "success")
        else:
            abort(404)
        db.session.commit()
    except WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return _back("items")


# --------------------------------------------------------------- claims ---
@bp.route("/claims/<int:claim_id>/reject", methods=["POST"])
@admin_required
def claim_reject(claim_id):
    claim = db.session.get(Claim, claim_id)
    if claim is None:
        abort(404)
    try:
        reject_claim(claim, g.user, request.form.get("note") or "Rejected after an administrator review.")
        db.session.commit()
        flash(f"Claim #{claim_id} was rejected.", "success")
    except WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return _back("claims")


# -------------------------------------------------------------- reports ---
@bp.route("/reports/<int:report_id>/resolve", methods=["POST"])
@admin_required
def report_resolve(report_id):
    rep = db.session.get(Report, report_id)
    if rep is None:
        abort(404)
    new_status = request.form.get("status", ReportStatus.REVIEWED)
    if new_status not in (ReportStatus.REVIEWED, ReportStatus.ACTIONED, ReportStatus.DISMISSED):
        abort(400)
    user_action_name = request.form.get("user_action", "")
    note = request.form.get("note", "").strip()[:255]
    try:
        if user_action_name in ("warn", "restrict", "block") and rep.reported_user is not None:
            apply_user_action(rep.reported_user, user_action_name, note or f"Report: {rep.reason}")
            new_status = ReportStatus.ACTIONED
        if request.form.get("remove_item") == "yes" and rep.item.status != ItemStatus.REMOVED:
            admin_remove_item(rep.item, g.user, note or rep.reason)
            new_status = ReportStatus.ACTIONED
        rep.status = new_status
        rep.admin_note = note or None
        rep.resolved_by_id = g.user.user_id
        rep.resolved_at = utcnow()
        notify(rep.reporter, Kind.ADMIN_NOTICE,
               f"Your report about \"{rep.item.title}\" was reviewed. Thank you.", None)
        audit("report.resolved", "report", rep.report_id, f"{new_status} {user_action_name}".strip())
        db.session.commit()
        flash(f"Report #{rep.report_id} marked as {new_status}.", "success")
    except WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    return _back("reports")


@bp.route("/messages/<int:message_id>/clear-flag", methods=["POST"])
@admin_required
def clear_flag(message_id):
    msg = db.session.get(Message, message_id)
    if msg is None:
        abort(404)
    msg.is_flagged = False
    audit("message.flag_cleared", "message", message_id)
    db.session.commit()
    flash("Flag cleared.", "success")
    return _back("reports")


# ------------------------------------------------------------ locations ---
def _parse_location_form(form):
    name = " ".join(form.get("name", "").split())[:120]
    try:
        lat = float(form.get("latitude", ""))
        lng = float(form.get("longitude", ""))
    except ValueError:
        raise WorkflowError("Enter numeric latitude and longitude (click the map to fill them).")
    if not name:
        raise WorkflowError("Enter a location name.")
    if not (-90 <= lat <= 90 and -180 <= lng <= 180):
        raise WorkflowError("Latitude/longitude out of range.")
    return name, lat, lng, form.get("is_handover_point") == "on"


@bp.route("/locations", methods=["POST"])
@admin_required
def location_create():
    try:
        name, lat, lng, handover = _parse_location_form(request.form)
        loc = CampusLocation(name=name, latitude=lat, longitude=lng, is_handover_point=handover)
        db.session.add(loc)
        db.session.flush()
        audit("location.created", "location", loc.location_id, name)
        db.session.commit()
        flash(f"Location \"{name}\" added.", "success")
    except WorkflowError as exc:
        flash(str(exc), "error")
    except IntegrityError:
        db.session.rollback()
        flash("A location with that name already exists.", "error")
    return _back("locations")


@bp.route("/locations/<int:location_id>", methods=["POST"])
@admin_required
def location_update(location_id):
    loc = db.session.get(CampusLocation, location_id)
    if loc is None:
        abort(404)
    action = request.form.get("action", "save")
    try:
        if action == "toggle":
            loc.is_active = not loc.is_active
            flash(f"\"{loc.name}\" is now {'shown' if loc.is_active else 'hidden'} in the location list.", "success")
        else:
            loc.name, loc.latitude, loc.longitude, loc.is_handover_point = _parse_location_form(request.form)
            flash(f"\"{loc.name}\" saved.", "success")
        audit(f"location.{action}", "location", loc.location_id, loc.name)
        db.session.commit()
    except WorkflowError as exc:
        db.session.rollback()
        flash(str(exc), "error")
    except IntegrityError:
        db.session.rollback()
        flash("A location with that name already exists.", "error")
    return _back("locations")


# ------------------------------------------------------------- settings ---
@bp.route("/settings", methods=["POST"])
@admin_required
def settings_save():
    errors = []
    for key in SETTINGS_SCHEMA:
        if key in request.form:
            try:
                set_setting(key, request.form[key])
            except ValueError as exc:
                errors.append(f"{SETTINGS_SCHEMA[key][0]}: {exc if str(exc) else 'invalid value'}")
    if errors:
        db.session.rollback()
        for e in errors:
            flash(e, "error")
    else:
        audit("settings.updated", "settings", None)
        db.session.commit()
        flash("Settings saved.", "success")
    return _back("settings")
