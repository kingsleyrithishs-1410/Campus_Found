"""Landing page, community feed, notifications, profile and media."""
import os
from datetime import date, datetime

from flask import (Blueprint, abort, current_app, g, jsonify, redirect,
                   render_template, request, send_from_directory, url_for)
from sqlalchemy import or_

from extensions import db
from models import (CATEGORIES, CampusLocation, Claim, ClaimStatus, Item, ItemStatus,
                    ItemType, Notification)
from services.matching import find_matches
from services.uploads import item_upload_dir
from utils.access import can_view_item
from utils.security import is_safe_next, login_required

bp = Blueprint("main", __name__)


def _parse_date(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def _like(term):
    escaped = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


@bp.route("/")
def index():
    if g.user:
        return redirect(url_for("main.feed"))
    recent = (Item.query.filter_by(status=ItemStatus.ACTIVE)
              .order_by(Item.created_at.desc()).limit(3).all())
    stats = {
        "returned": Item.query.filter(Item.status == ItemStatus.COMPLETED,
                                      Item.item_type == ItemType.FOUND).count(),
        "active": Item.query.filter_by(status=ItemStatus.ACTIVE).count(),
    }
    locations = CampusLocation.query.filter_by(is_active=True).all()
    counts, _ = location_activity(locations)
    return render_template("index.html", recent=recent, stats=stats,
                           hero_spot=counts[0] if counts else None)


@bp.route("/feed")
@login_required
def feed():
    args = request.args
    q = (args.get("q") or "").strip()[:100]
    item_type = args.get("type", "")
    category = args.get("category", "")
    location = args.get("location", "")
    date_from = _parse_date(args.get("from"))
    date_to = _parse_date(args.get("to"))
    page = max(args.get("page", 1, type=int), 1)

    query = Item.query.filter(Item.status == ItemStatus.ACTIVE)   # only ACTIVE items are public
    if item_type in ItemType.ALL:
        query = query.filter(Item.item_type == item_type)
    if category in CATEGORIES:
        query = query.filter(Item.category == category)
    if location:
        query = query.filter(Item.location_name == location)
    if date_from:
        query = query.filter(Item.event_date >= date_from)
    if date_to:
        query = query.filter(Item.event_date <= date_to)
    if q:
        pattern = _like(q)
        query = query.filter(or_(
            Item.title.ilike(pattern, escape="\\"),
            Item.description.ilike(pattern, escape="\\"),
            Item.location_name.ilike(pattern, escape="\\"),
            Item.category.ilike(pattern, escape="\\"),
        ))

    pagination = (query.order_by(Item.created_at.desc())).paginate(page=page, per_page=current_app.config["FEED_PAGE_SIZE"], error_out=False,
    )

    # Possible matches for the viewer's own open lost reports.
    my_matches = []
    my_lost = (Item.query.filter(Item.owner_id == g.user.user_id,
                                 Item.item_type == ItemType.LOST,
                                 Item.status == ItemStatus.ACTIVE)
               .order_by(Item.created_at.desc()).limit(5).all())
    for lost in my_lost:
        for match in find_matches(lost, limit=2):
            my_matches.append((lost, match))
    my_matches = my_matches[:3]

    locations = CampusLocation.query.filter_by(is_active=True).order_by(CampusLocation.name).all()
    map_points = []
    for item in pagination.items:
        coords = item.public_coords()
        if coords:
            map_points.append({
                "lat": coords[0], "lng": coords[1], "title": item.title,
                "type": item.item_type, "location": item.location_name,
                "url": url_for("items.detail", item_id=item.item_id),
            })

    filters_active = any([q, item_type, category, location, date_from, date_to])
    location_counts, side_places = location_activity(locations)
    return render_template(
        "feed.html", pagination=pagination, items=pagination.items, q=q,
        item_type=item_type, category=category, location=location,
        date_from=args.get("from", ""), date_to=args.get("to", ""),
        categories=CATEGORIES, locations=locations, my_matches=my_matches,
        map_points=map_points, filters_active=filters_active,
        location_counts=location_counts[:6], side_places=side_places,
        hero_spot=location_counts[0] if location_counts else None,
        today=date.today().isoformat(),
    )


def location_activity(locations):
    """Active report counts per place, busiest first, plus map markers."""
    rows = (db.session.query(Item.location_name, db.func.count(Item.item_id))
            .filter(Item.status == ItemStatus.ACTIVE)
            .group_by(Item.location_name)
            .order_by(db.func.count(Item.item_id).desc(), Item.location_name)
            .all())
    counts = [(name, count) for name, count in rows]
    by_name = dict(counts)
    places = [
        {"name": loc.name, "lat": loc.latitude, "lng": loc.longitude,
         "count": by_name.get(loc.name, 0),
         "url": url_for("main.feed", location=loc.name) + "#board"}
        for loc in locations
    ]
    return counts, places


@bp.route("/notifications")
@login_required
def notifications():
    notes = (Notification.query.filter_by(user_id=g.user.user_id)
             .order_by(Notification.created_at.desc()).limit(100).all())
    return render_template("notifications.html", notes=notes)


@bp.route("/notifications/<int:notification_id>/open")
@login_required
def open_notification(notification_id):
    note = db.session.get(Notification, notification_id)
    if note is None or note.user_id != g.user.user_id:
        abort(404)
    note.is_read = True
    db.session.commit()
    if note.link and is_safe_next(note.link):
        return redirect(note.link)
    return redirect(url_for("main.notifications"))


@bp.route("/notifications/read-all", methods=["POST"])
@login_required
def read_all_notifications():
    Notification.query.filter_by(user_id=g.user.user_id, is_read=False).update({"is_read": True})
    db.session.commit()
    return redirect(url_for("main.notifications"))


@bp.route("/profile")
@login_required
def profile():
    user = g.user
    my_items = user.items.order_by(Item.created_at.desc()).all()
    my_claims = (Claim.query.filter_by(claimant_id=user.user_id)
                 .order_by(Claim.created_at.desc()).all())
    incoming = (Claim.query.join(Item, Claim.item_id == Item.item_id)
                .filter(Item.owner_id == user.user_id)
                .order_by(Claim.created_at.desc()).all())
    pending_incoming = sum(1 for c in incoming if c.status == ClaimStatus.PENDING)
    return render_template("profile.html", my_items=my_items, my_claims=my_claims,
                           incoming=incoming, pending_incoming=pending_incoming)


@bp.route("/safety")
def safety():
    return render_template("safety.html")


@bp.route("/media/items/<path:filename>")
@login_required
def item_image(filename):
    """Item photos are visible to logged-in campus users only. The photo of a
    finished or removed report is only shown to its participants and admins."""
    safe_name = os.path.basename(filename)
    item = Item.query.filter_by(image_path=safe_name).first()
    if item is None:
        abort(404)
    if not can_view_item(item, g.user):
        abort(404)
    response = send_from_directory(item_upload_dir(), safe_name)
    response.headers["Cache-Control"] = "private, max-age=3600"
    return response


@bp.route("/api/locations")
@login_required
def api_locations():
    locations = CampusLocation.query.filter_by(is_active=True).order_by(CampusLocation.name).all()
    return jsonify([loc.to_dict() for loc in locations])
