"""Reporting lost/found items, item details, closing and flagging reports."""
from datetime import date, datetime, timedelta

from flask import (Blueprint, abort, flash, g, redirect, render_template, request,
                   url_for)

from extensions import db
from models import (CATEGORIES, REPORT_REASONS, CampusLocation, Claim, Item, ItemStatus,
                    ItemType, Report, ReportStatus)
from services.audit import audit
from services.matching import find_matches, haversine_m
from services.moderation import check_report_text
from services.notifications import Kind, notify
from services.settings import get_setting
from services.uploads import UploadError, delete_image, has_file, save_image
from services.workflow import WorkflowError, close_item
from utils.access import can_view_item
from utils.security import login_required, not_restricted, rate_limit

bp = Blueprint("items", __name__, url_prefix="/items")

MAX_CAMPUS_RADIUS_M = 10000   # pins further than this from the campus centre are rejected


def _float_or_none(value):
    try:
        return float(value) if value not in (None, "") else None
    except ValueError:
        return None


def parse_item_form(form, item_type):
    """Validate the report form. Returns (data, errors)."""
    errors = []
    title = " ".join(form.get("title", "").split())
    category = form.get("category", "")
    description = form.get("description", "").strip()
    location_choice = form.get("location_name", "")
    location_custom = " ".join(form.get("location_custom", "").split())
    location_details = " ".join(form.get("location_details", "").split())[:255]
    lat = _float_or_none(form.get("latitude"))
    lng = _float_or_none(form.get("longitude"))

    if not 3 <= len(title) <= 120:
        errors.append("Item name must be 3 to 120 characters.")
    if category not in CATEGORIES:
        errors.append("Choose a category.")
    if not 10 <= len(description) <= 2000:
        errors.append("Description must be 10 to 2000 characters.")

    event_date = None
    try:
        event_date = datetime.strptime(form.get("event_date", ""), "%Y-%m-%d").date()
    except ValueError:
        errors.append("Enter the date the item was " + ("lost." if item_type == ItemType.LOST else "found."))
    if event_date:
        if event_date > date.today():
            errors.append("The date can't be in the future.")
        elif event_date < date.today() - timedelta(days=365):
            errors.append("The date must be within the last year.")

    # Location: a predefined campus place, or a custom name (with a map pin).
    location_name = None
    if location_choice == "__custom__":
        if not 2 <= len(location_custom) <= 120:
            errors.append("Enter the name of the campus location.")
        else:
            location_name = location_custom
    elif location_choice:
        place = CampusLocation.query.filter_by(name=location_choice, is_active=True).first()
        if place is None:
            errors.append("Choose a campus location from the list.")
        else:
            location_name = place.name
            if lat is None or lng is None:
                lat, lng = place.latitude, place.longitude
    else:
        errors.append("Choose a campus location or click the map.")

    if (lat is None) != (lng is None):
        errors.append("The map pin is incomplete. Click the map again.")
        lat = lng = None
    if lat is not None:
        if not (-90 <= lat <= 90 and -180 <= lng <= 180):
            errors.append("The map pin is not a valid position.")
            lat = lng = None
        else:
            centre = (get_setting("campus_lat"), get_setting("campus_lng"))
            if haversine_m(lat, lng, *centre) > MAX_CAMPUS_RADIUS_M:
                errors.append("The map pin is too far from campus. Place it on the campus map.")

    for text in (title, description, location_details):
        problem = check_report_text(text)
        if problem:
            errors.append(problem)
            break

    data = {
        "title": title, "category": category, "description": description,
        "event_date": event_date, "location_name": location_name,
        "location_details": location_details or None, "latitude": lat, "longitude": lng,
        # Values to refill the form after an error:
        "location_choice": location_choice, "location_custom": location_custom,
        "event_date_raw": form.get("event_date", ""),
    }
    return data, errors


def notify_matches(item):
    matches = find_matches(item, limit=5)
    if not matches:
        return matches
    link = url_for("items.detail", item_id=item.item_id)
    if item.is_found:
        for m in matches:
            notify(m.item.owner, Kind.POSSIBLE_MATCH,
                   f"Possible match: a found \"{item.title}\" may be your lost \"{m.item.title}\".",
                   link)
    else:
        notify(item.owner, Kind.POSSIBLE_MATCH,
               f"{len(matches)} found report(s) may match your lost \"{item.title}\".", link)
    return matches


@bp.route("/new", methods=["GET", "POST"])
@login_required
@not_restricted
@rate_limit(20, 3600, scope="user")
def new():
    item_type = request.values.get("type", ItemType.FOUND)
    if item_type not in ItemType.ALL:
        abort(404)
    locations = CampusLocation.query.filter_by(is_active=True).order_by(CampusLocation.name).all()

    if request.method == "POST":
        data, errors = parse_item_form(request.form, item_type)
        photo = request.files.get("photo")
        image_name = None
        if not errors and has_file(photo):
            try:
                image_name = save_image(photo)
            except UploadError as exc:
                errors.append(str(exc))
        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("item_form.html", item_type=item_type, data=data,
                                   categories=CATEGORIES, locations=locations,
                                   today=date.today().isoformat()), 400

        item = Item(
            title=data["title"], category=data["category"], description=data["description"],
            location_name=data["location_name"], location_details=data["location_details"],
            latitude=data["latitude"], longitude=data["longitude"],
            event_date=data["event_date"], item_type=item_type, image_path=image_name,
            status=ItemStatus.ACTIVE, owner_id=g.user.user_id,
        )
        db.session.add(item)
        try:
            db.session.flush()
            audit("item.created", "item", item.item_id, item_type)
            matches = notify_matches(item)
            db.session.commit()
        except Exception:
            db.session.rollback()
            delete_image(image_name)
            raise

        if item.is_found:
            flash("Thanks! Your found report is live in the campus feed.", "success")
        else:
            flash("Your lost report is live. We'll notify you about possible matches.", "success")
        if matches:
            flash(f"We found {len(matches)} possible match(es). They are listed below.", "match")
        return redirect(url_for("items.detail", item_id=item.item_id))

    data = {"event_date_raw": date.today().isoformat()}
    return render_template("item_form.html", item_type=item_type, data=data,
                           categories=CATEGORIES, locations=locations,
                           today=date.today().isoformat())


@bp.route("/<int:item_id>")
@login_required
def detail(item_id):
    item = db.session.get(Item, item_id)
    if item is None or not can_view_item(item, g.user):
        abort(404)
    is_owner = item.owner_id == g.user.user_id
    my_claim = None
    if item.is_found:
        my_claim = Claim.query.filter_by(item_id=item.item_id, claimant_id=g.user.user_id).first()

    claims = item.claims.all() if (is_owner or g.user.is_admin) and item.is_found else []
    matches = []
    if item.status in ItemStatus.OPEN and (item.is_lost or is_owner):
        matches = find_matches(item)

    can_claim = (item.is_found and not is_owner and my_claim is None
                 and item.status in (ItemStatus.ACTIVE, ItemStatus.CLAIM_REQUESTED))
    already_reported = Report.query.filter_by(
        item_id=item.item_id, reporter_id=g.user.user_id, claim_id=None, status=ReportStatus.OPEN
    ).first() is not None
    coords = item.public_coords()
    return render_template(
        "item_detail.html", item=item, is_owner=is_owner, my_claim=my_claim,
        claims=claims, matches=matches, can_claim=can_claim, coords=coords,
        report_reasons=REPORT_REASONS, already_reported=already_reported,
    )


@bp.route("/<int:item_id>/close", methods=["POST"])
@login_required
def close(item_id):
    item = db.session.get(Item, item_id)
    if item is None:
        abort(404)
    reason = request.form.get("reason", "closed")
    try:
        close_item(item, g.user, reason)
    except WorkflowError as exc:
        flash(str(exc), "error")
        return redirect(url_for("items.detail", item_id=item_id))
    db.session.commit()
    flash("Report closed and removed from the public feed. The record is kept.", "success")
    return redirect(url_for("main.profile"))


@bp.route("/<int:item_id>/report", methods=["POST"])
@login_required
@rate_limit(10, 3600, scope="user")
def report(item_id):
    item = db.session.get(Item, item_id)
    if item is None or not can_view_item(item, g.user):
        abort(404)
    reason = request.form.get("reason", "")
    details = request.form.get("details", "").strip()[:1000]
    if reason not in REPORT_REASONS:
        flash("Choose a reason for the report.", "error")
        return redirect(url_for("items.detail", item_id=item_id))
    if item.owner_id == g.user.user_id:
        flash("You can't report your own item.", "error")
        return redirect(url_for("items.detail", item_id=item_id))
    existing = Report.query.filter_by(item_id=item_id, reporter_id=g.user.user_id,
                                      claim_id=None, status=ReportStatus.OPEN).first()
    if existing:
        flash("You've already reported this item. An administrator will review it.", "info")
        return redirect(url_for("items.detail", item_id=item_id))
    rep = Report(item_id=item_id, reporter_id=g.user.user_id, reported_user_id=item.owner_id,
                 reason=reason, details=details or None)
    db.session.add(rep)
    db.session.flush()
    audit("report.created", "report", rep.report_id, f"item {item_id}: {reason}")
    db.session.commit()
    flash("Thanks. The report was sent to the administrators.", "success")
    return redirect(url_for("items.detail", item_id=item_id))
