/* Small progressive enhancements. Every page works without JavaScript. */
(function () {
  "use strict";

  // Dismiss flash messages
  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-dismiss]");
    if (btn) btn.parentElement.remove();
  });

  // Ask before destructive or final actions
  document.addEventListener("submit", function (e) {
    var form = e.target.closest("form[data-confirm]");
    if (form && !window.confirm(form.getAttribute("data-confirm"))) e.preventDefault();
  });

  // Close the account menu when clicking elsewhere
  document.addEventListener("click", function (e) {
    document.querySelectorAll("details.usermenu[open]").forEach(function (d) {
      if (!d.contains(e.target)) d.removeAttribute("open");
    });
  });

  // Report pop-up: "I lost / I found something" opens the form over the board
  var dialog = document.getElementById("report-dialog");
  function setReportType(type) {
    var card = dialog.querySelector("[data-report-card]");
    card.querySelector("[data-report-type]").value = type;
    card.querySelectorAll("[data-swap], [data-report-title]").forEach(function (el) {
      el.textContent = el.getAttribute("data-" + type);
    });
  }
  if (dialog && typeof dialog.showModal === "function") {
    document.addEventListener("click", function (e) {
      var trigger = e.target.closest("[data-report]");
      if (!trigger) return;
      e.preventDefault();
      setReportType(trigger.getAttribute("data-report"));
      dialog.showModal();
      document.dispatchEvent(new CustomEvent("reportdialog:open"));
      var first = dialog.querySelector("#title");
      if (first) first.focus();
    });
    dialog.addEventListener("click", function (e) {
      if (e.target === dialog || e.target.closest("[data-close-dialog]")) dialog.close();
    });
  }

  // Board filters apply as soon as they change
  document.querySelectorAll("[data-autosubmit]").forEach(function (el) {
    el.addEventListener("change", function () { el.form.submit(); });
  });

  // Photo preview + early size/type check (the server checks again)
  var MAX_BYTES = 5 * 1024 * 1024;
  var OK_TYPES = ["image/png", "image/jpeg", "image/webp"];
  document.querySelectorAll("input[type=file][data-preview]").forEach(function (input) {
    var preview = document.querySelector(input.getAttribute("data-preview"));
    input.addEventListener("change", function () {
      var file = input.files && input.files[0];
      input.setCustomValidity("");
      if (!file) { if (preview) preview.hidden = true; return; }
      if (OK_TYPES.indexOf(file.type) === -1) {
        input.setCustomValidity("Choose a PNG, JPG or WEBP photo.");
      } else if (file.size > MAX_BYTES) {
        input.setCustomValidity("This photo is larger than 5 MB. Choose a smaller one.");
      }
      if (!input.checkValidity()) {
        input.reportValidity();
        input.value = "";
        if (preview) preview.hidden = true;
        return;
      }
      if (preview) {
        preview.src = URL.createObjectURL(file);
        preview.hidden = false;
      }
      var label = input.closest("label") && input.closest("label").querySelector("[data-photo-label]");
      if (label) label.textContent = file.name;
    });
  });

  // Registration: show when the passwords don't match yet
  var pwForm = document.querySelector("[data-password-form]");
  if (pwForm) {
    var pw = pwForm.querySelector("#password");
    var confirmPw = pwForm.querySelector("#confirm_password");
    var warn = pwForm.querySelector("[data-password-mismatch]");
    var check = function () {
      warn.hidden = !confirmPw.value || confirmPw.value === pw.value;
    };
    pw.addEventListener("input", check);
    confirmPw.addEventListener("input", check);
  }

  // Filters are open by default on wide screens
  var wide = window.matchMedia("(min-width: 900px)");
  document.querySelectorAll("details[data-open-desktop]").forEach(function (d) {
    if (wide.matches) d.setAttribute("open", "");
  });

  // Feed: cards / map toggle
  var toggle = document.querySelector(".viewtoggle");
  if (toggle) {
    var cards = document.querySelector("[data-cards]");
    var map = document.getElementById("feed-map");
    var show = function (view) {
      toggle.querySelectorAll("button").forEach(function (b) {
        b.setAttribute("aria-pressed", String(b.getAttribute("data-view") === view));
      });
      if (cards) cards.hidden = view === "map";
      map.hidden = view !== "map";
      if (view === "map") document.dispatchEvent(new CustomEvent("feedmap:show"));
    };
    toggle.addEventListener("click", function (e) {
      var b = e.target.closest("button[data-view]");
      if (b) show(b.getAttribute("data-view"));
    });
    if (new URLSearchParams(window.location.search).get("view") === "map") show("map");
  }
})();
