/* Campus maps (Leaflet + OpenStreetMap).
 *  - [data-picker]      report form: choose a campus place or click to drop a pin
 *  - [data-detail-map]  item page: approximate area (circle, not the exact spot)
 *  - #feed-map          feed: active reports at rounded positions
 *  - [data-admin-map]   admin: click to fill coordinates for a new location
 */
(function () {
  "use strict";
  if (typeof L === "undefined") return;

  var COLORS = { lost: "#CF3626", found: "#12814A", place: "#1E4FD6" };
  var SNAP_METERS = 80;

  function readJSON(id) {
    var el = document.getElementById(id);
    if (!el) return null;
    try { return JSON.parse(el.textContent); } catch (e) { return null; }
  }

  function baseMap(el, center, zoom) {
    var map = L.map(el, { scrollWheelZoom: false }).setView([center.lat, center.lng], zoom || center.zoom || 17);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
    map.on("focus", function () { map.scrollWheelZoom.enable(); });
    map.on("blur", function () { map.scrollWheelZoom.disable(); });
    return map;
  }

  function el(tag, text, attrs) {
    var node = document.createElement(tag);
    if (text) node.textContent = text;
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, attrs[k]); });
    return node;
  }

  // ------------------------------------------------------------ report form
  var picker = document.querySelector("[data-picker]");
  if (picker) {
    var cfg = readJSON("map-config") || { lat: 0, lng: 0, zoom: 17 };
    var select = document.querySelector("[data-location-select]");
    var customBox = document.querySelector("[data-custom-location]");
    var customInput = document.getElementById("location_custom");
    var latInput = document.querySelector("[data-lat-input]");
    var lngInput = document.querySelector("[data-lng-input]");
    var status = document.querySelector("[data-pin-status]");
    var map = baseMap(picker, cfg);
    var pin = null;

    var places = Array.prototype.slice.call(select.options)
      .filter(function (o) { return o.dataset.lat; })
      .map(function (o) {
        var p = { name: o.value, lat: parseFloat(o.dataset.lat), lng: parseFloat(o.dataset.lng) };
        L.circleMarker([p.lat, p.lng], { radius: 7, color: COLORS.place, weight: 2, fillOpacity: 0.25 })
          .addTo(map)
          .bindTooltip(p.name)
          .on("click", function (e) {
            L.DomEvent.stopPropagation(e);
            select.value = p.name;
            onSelect();
          });
        return p;
      });

    function setPin(lat, lng, label) {
      latInput.value = lat.toFixed(6);
      lngInput.value = lng.toFixed(6);
      if (pin) pin.setLatLng([lat, lng]);
      else pin = L.marker([lat, lng], { keyboard: false }).addTo(map);
      status.textContent = "Pin set" + (label ? " at " + label : "") + " (" + lat.toFixed(5) + ", " + lng.toFixed(5) + ")";
    }

    function toggleCustom() {
      var custom = select.value === "__custom__";
      customBox.hidden = !custom;
      customInput.required = custom;
    }

    function onSelect() {
      toggleCustom();
      var opt = select.options[select.selectedIndex];
      if (opt && opt.dataset.lat) {
        var lat = parseFloat(opt.dataset.lat), lng = parseFloat(opt.dataset.lng);
        setPin(lat, lng, opt.value);
        map.setView([lat, lng], Math.max(map.getZoom(), 17));
      } else if (select.value === "__custom__") {
        customInput.focus();
      }
    }

    select.addEventListener("change", onSelect);

    map.on("click", function (e) {
      var here = e.latlng, nearest = null, best = Infinity;
      places.forEach(function (p) {
        var d = here.distanceTo([p.lat, p.lng]);
        if (d < best) { best = d; nearest = p; }
      });
      if (nearest && best <= SNAP_METERS) {
        select.value = nearest.name;
        toggleCustom();
        setPin(here.lat, here.lng, nearest.name);
      } else {
        select.value = "__custom__";
        toggleCustom();
        setPin(here.lat, here.lng, null);
        status.textContent += ". Type a name for this place above.";
        customInput.focus();
      }
    });

    // The picker may start hidden (inside the pop-up or a closed <details>).
    var refresh = function () { setTimeout(function () { map.invalidateSize(); }, 30); };
    var pinbox = picker.closest("details");
    if (pinbox) pinbox.addEventListener("toggle", function () {
      refresh();
      if (pinbox.open && !latInput.value) onSelect();
    });
    document.addEventListener("reportdialog:open", refresh);

    toggleCustom();
    if (latInput.value && lngInput.value) {
      setPin(parseFloat(latInput.value), parseFloat(lngInput.value), select.value !== "__custom__" ? select.value : null);
      map.setView([parseFloat(latInput.value), parseFloat(lngInput.value)], 17);
    }
  }

  // ------------------------------------------------------------ item page
  var detail = document.querySelector("[data-detail-map]");
  if (detail) {
    var lat = parseFloat(detail.dataset.lat), lng = parseFloat(detail.dataset.lng);
    var dmap = baseMap(detail, { lat: lat, lng: lng }, 17);
    L.circle([lat, lng], {
      radius: 110, color: COLORS[detail.dataset.type] || COLORS.place, weight: 2, fillOpacity: 0.15
    }).addTo(dmap).bindTooltip(detail.dataset.label, { permanent: true, direction: "top" });
  }

  // ------------------------------------------------------------ feed map
  var feedEl = document.getElementById("feed-map");
  if (feedEl) {
    var feedMap = null;
    document.addEventListener("feedmap:show", function () {
      var data = readJSON("feed-map-data") || { points: [], center: { lat: 0, lng: 0, zoom: 17 } };
      if (feedMap) { feedMap.invalidateSize(); return; }
      feedMap = baseMap(feedEl, data.center);
      var bounds = [];
      data.points.forEach(function (p) {
        var popup = el("div");
        popup.appendChild(el("strong", (p.type === "found" ? "🟢 FOUND: " : "🔴 LOST: ") + p.title));
        popup.appendChild(el("br"));
        popup.appendChild(el("span", "📍 " + p.location));
        popup.appendChild(el("br"));
        popup.appendChild(el("a", "View details", { href: p.url }));
        L.circleMarker([p.lat, p.lng], {
          radius: 9, color: COLORS[p.type], weight: 2, fillColor: COLORS[p.type], fillOpacity: 0.5
        }).addTo(feedMap).bindPopup(popup);
        bounds.push([p.lat, p.lng]);
      });
      if (bounds.length > 1) feedMap.fitBounds(bounds, { padding: [40, 40], maxZoom: 18 });
      else if (bounds.length === 1) feedMap.setView(bounds[0], 17);
      if (!data.points.length) {
        var note = el("p", "No reports on this page have a map pin.", { "class": "feedmap__empty" });
        feedEl.appendChild(note);
      }
    });
  }

  // ------------------------------------------------------------ board side map
  var sideEl = document.querySelector("[data-side-map]");
  if (sideEl) {
    var sdata = readJSON("side-map-data") || { center: { lat: 0, lng: 0, zoom: 16 }, places: [] };
    var smap = baseMap(sideEl, sdata.center, Math.max((sdata.center.zoom || 17) - 1, 14));
    var withItems = [];
    sdata.places.forEach(function (p) {
      var busy = p.count > 0;
      var icon = L.divIcon({
        className: "", iconSize: busy ? [30, 30] : [12, 12],
        html: '<span class="place-dot' + (busy ? '' : ' place-dot--empty') + '" style="' + (busy ? '' : 'width:12px;height:12px;border-width:2px') + '">' + (busy ? p.count : '') + '</span>'
      });
      var marker = L.marker([p.lat, p.lng], { icon: icon, keyboard: false }).addTo(smap)
        .bindTooltip(p.name + (busy ? " (" + p.count + ")" : ""));
      marker.on("click", function () { window.location.href = p.url; });
      if (busy) withItems.push([p.lat, p.lng]);
    });
    if (withItems.length > 1) smap.fitBounds(withItems, { padding: [30, 30], maxZoom: 17 });
  }

  // ------------------------------------------------------------ admin
  var adminEl = document.querySelector("[data-admin-map]");
  if (adminEl) {
    var adata = readJSON("admin-locations") || { center: { lat: 0, lng: 0, zoom: 17 }, locations: [] };
    var amap = baseMap(adminEl, adata.center);
    adata.locations.forEach(function (p) {
      L.circleMarker([p.lat, p.lng], { radius: 7, color: p.handover ? COLORS.found : COLORS.place, weight: 2, fillOpacity: 0.3 })
        .addTo(amap).bindTooltip(p.name + (p.handover ? " (hand-over point)" : ""));
    });
    var newPin = null;
    amap.on("click", function (e) {
      document.querySelector("[data-admin-lat]").value = e.latlng.lat.toFixed(6);
      document.querySelector("[data-admin-lng]").value = e.latlng.lng.toFixed(6);
      if (newPin) newPin.setLatLng(e.latlng); else newPin = L.marker(e.latlng).addTo(amap);
    });
  }
})();
