/* Item conversation: suggested messages, sending without reload, polling.
 * Polling keeps the MVP simple; the JSON endpoints can later be served over
 * WebSockets without changing the page. */
(function () {
  "use strict";
  var thread = document.querySelector("[data-thread]");
  if (!thread) return;

  var form = document.querySelector("[data-chat-form]");
  var input = document.querySelector("[data-chat-input]");
  var errorBox = document.querySelector("[data-chat-error]");
  var csrf = document.querySelector('meta[name="csrf-token"]').getAttribute("content");
  var lastId = parseInt(thread.getAttribute("data-last-id"), 10) || 0;
  var pollUrl = thread.getAttribute("data-poll-url");
  var seen = {};
  thread.querySelectorAll("[data-id]").forEach(function (li) { seen[li.getAttribute("data-id")] = true; });

  function scrollDown() { thread.scrollTop = thread.scrollHeight; }
  scrollDown();

  function render(m) {
    if (seen[m.id]) return;
    seen[m.id] = true;
    var li = document.createElement("li");
    li.className = "msg " + (m.system ? "msg--system" : m.mine ? "msg--mine" : "msg--theirs");
    li.setAttribute("data-id", m.id);
    if (!m.system) {
      var who = document.createElement("span");
      who.className = "msg__who";
      who.textContent = m.mine ? "You" : m.sender;
      li.appendChild(who);
    }
    var body = document.createElement("p");
    body.className = "msg__body";
    body.textContent = m.body;            // textContent: never inject HTML
    li.appendChild(body);
    var time = document.createElement("span");
    time.className = "msg__time";
    time.textContent = m.time;
    li.appendChild(time);
    thread.appendChild(li);
    lastId = Math.max(lastId, m.id);
  }

  function showError(text) {
    if (!errorBox) return;
    errorBox.textContent = text || "";
    errorBox.hidden = !text;
  }

  // Suggested messages: put the text in the box so it can be edited before sending
  document.querySelectorAll("[data-suggestion]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      input.value = btn.getAttribute("data-suggestion");
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
      showError("");
    });
  });

  if (form) {
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        form.requestSubmit ? form.requestSubmit() : form.submit();
      }
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var text = input.value.trim();
      if (!text) { showError("Type a message before sending."); return; }
      var button = form.querySelector("button[type=submit]");
      button.disabled = true;
      fetch(form.action, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json", "Accept": "application/json", "X-CSRFToken": csrf },
        body: JSON.stringify({ body: text })
      })
        .then(function (r) {
          return r.json().catch(function () { return { ok: false, error: "Could not send. Try again." }; });
        })
        .then(function (data) {
          if (data.ok) {
            render(data.message);
            input.value = "";
            showError("");
            scrollDown();
          } else {
            showError(data.error);
          }
        })
        .catch(function () { showError("No connection. Your message wasn't sent."); })
        .finally(function () { button.disabled = false; input.focus(); });
    });
  }

  // Poll for new messages and status changes
  var initialStatus = thread.getAttribute("data-status");
  function poll() {
    if (document.hidden) return;
    fetch(pollUrl + "?after=" + lastId, { credentials: "same-origin", headers: { "Accept": "application/json" } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data || !data.ok) return;
        var nearBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 80;
        data.messages.forEach(render);
        if (data.messages.length && nearBottom) scrollDown();
        // The claim was approved/rejected/returned elsewhere: refresh the panel
        // (unless the user is in the middle of typing).
        if (data.status !== initialStatus && (!input || !input.value.trim())) window.location.reload();
      })
      .catch(function () { /* try again next tick */ });
  }
  setInterval(poll, 5000);
})();
