"""Notifications.

The MVP stores in-app notifications. Delivery is routed through a list of
channels, so email or push delivery can be added later by appending a channel
class with a ``send(notification)`` method - no route code needs to change.
"""
from extensions import db
from models import Notification


class Kind:
    POSSIBLE_MATCH = "possible_match"
    CLAIM_RECEIVED = "claim_received"
    CLAIM_APPROVED = "claim_approved"
    CLAIM_REJECTED = "claim_rejected"
    NEW_MESSAGE = "new_message"
    ITEM_RETURNED = "item_returned"
    ADMIN_WARNING = "admin_warning"
    ADMIN_NOTICE = "admin_notice"


ICONS = {
    Kind.POSSIBLE_MATCH: "🔔",
    Kind.CLAIM_RECEIVED: "🙋",
    Kind.CLAIM_APPROVED: "🔐",
    Kind.CLAIM_REJECTED: "✖️",
    Kind.NEW_MESSAGE: "💬",
    Kind.ITEM_RETURNED: "✓",
    Kind.ADMIN_WARNING: "⚠️",
    Kind.ADMIN_NOTICE: "🛡️",
}


class InAppChannel:
    """Notifications are already rows in the database; nothing else to do."""

    def send(self, notification):
        return True


# Future: EmailChannel(), PushChannel() ...
CHANNELS = [InAppChannel()]


def notify(user, kind, message, link=None):
    if user is None:
        return None
    note = Notification(user_id=user.user_id, kind=kind, message=message[:255], link=link)
    db.session.add(note)
    for channel in CHANNELS:
        channel.send(note)
    return note


def notify_new_message(claim, sender, link):
    """Notify the other participant, without flooding: skip if they already
    have an unread message notification for this conversation."""
    recipient = claim.item.owner if sender.user_id == claim.claimant_id else claim.claimant
    existing = Notification.query.filter_by(
        user_id=recipient.user_id, kind=Kind.NEW_MESSAGE, link=link, is_read=False
    ).first()
    if existing:
        return existing
    return notify(
        recipient, Kind.NEW_MESSAGE,
        f"New message about \"{claim.item.title}\" (claim #{claim.claim_id})", link,
    )


def unread_count(user):
    if user is None:
        return 0
    return Notification.query.filter_by(user_id=user.user_id, is_read=False).count()
