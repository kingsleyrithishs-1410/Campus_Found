"""Claim and item status workflow.

    ACTIVE -> CLAIM_REQUESTED -> CLAIM_APPROVED -> (returned) -> COMPLETED
                     |                  |
                     +--- rejected -----+--> back to ACTIVE (if no other open claims)

All state changes go through these functions so the rules live in one place.
Each function raises WorkflowError with a user-facing message when an action
is not allowed. Callers commit the session.
"""
from flask import url_for
from sqlalchemy.exc import IntegrityError

from extensions import db
from models import Claim, ClaimStatus, Item, ItemStatus, ItemType, Message, utcnow
from services.audit import audit
from services.notifications import Kind, notify


class WorkflowError(Exception):
    pass


def system_message(claim, body):
    msg = Message(claim_id=claim.claim_id, sender_id=None, body=body)
    db.session.add(msg)
    return msg


def _chat_link(claim):
    return url_for("chat.conversation", claim_id=claim.claim_id)


def _open_claims(item, exclude_id=None):
    q = item.claims.filter(Claim.status.in_(ClaimStatus.OPEN))
    if exclude_id:
        q = q.filter(Claim.claim_id != exclude_id)
    return q.all()


def _refresh_item_status(item):
    """Derive the found item's status from its claims (unless it is finished)."""
    if item.status in (ItemStatus.COMPLETED, ItemStatus.CLOSED, ItemStatus.REMOVED):
        return
    open_claims = _open_claims(item)
    if any(c.status == ClaimStatus.APPROVED for c in open_claims):
        item.status = ItemStatus.CLAIM_APPROVED
    elif open_claims:
        item.status = ItemStatus.CLAIM_REQUESTED
    else:
        item.status = ItemStatus.ACTIVE


# --------------------------------------------------------------------------
def submit_claim(item, user, proof, serial_number=None, purchase_info=None,
                 unique_marks=None, proof_image_path=None, lost_item=None):
    if not item.is_found:
        raise WorkflowError("Only found items can be claimed.")
    if item.owner_id == user.user_id:
        raise WorkflowError("You reported this item, so you can't claim it.")
    if item.status not in (ItemStatus.ACTIVE, ItemStatus.CLAIM_REQUESTED):
        raise WorkflowError("This item is no longer accepting claims.")
    if Claim.query.filter_by(item_id=item.item_id, claimant_id=user.user_id).first():
        raise WorkflowError("You have already submitted a claim for this item.")
    if lost_item is not None and (lost_item.owner_id != user.user_id or lost_item.item_type != ItemType.LOST):
        lost_item = None

    claim = Claim(
        item_id=item.item_id, claimant_id=user.user_id, proof=proof,
        serial_number=serial_number or None, purchase_info=purchase_info or None,
        unique_marks=unique_marks or None, proof_image_path=proof_image_path,
        lost_item_id=lost_item.item_id if lost_item else None,
        status=ClaimStatus.PENDING,
    )
    db.session.add(claim)
    try:
        db.session.flush()
    except IntegrityError:
        db.session.rollback()
        raise WorkflowError("You have already submitted a claim for this item.")

    item.status = ItemStatus.CLAIM_REQUESTED
    system_message(
        claim,
        f"Claim #{claim.claim_id} opened for \"{item.title}\". "
        "The finder will review the private ownership proof. Keep this conversation about the item "
        "and arrange any hand-over at an approved campus location.",
    )
    notify(item.owner, Kind.CLAIM_RECEIVED,
           f"{user.public_name} claimed your found item \"{item.title}\". Review their proof.",
           _chat_link(claim))
    audit("claim.submitted", "claim", claim.claim_id, f"item {item.item_id}", actor=user)
    return claim


def add_proof(claim, user, text):
    if user.user_id != claim.claimant_id:
        raise WorkflowError("Only the claimant can add proof.")
    if claim.status != ClaimStatus.PENDING:
        raise WorkflowError("Proof can only be added while the claim is pending.")
    text = (text or "").strip()
    if len(text) < 5:
        raise WorkflowError("Describe the additional proof in a few words.")
    stamp = utcnow().strftime("%d %b %Y %H:%M UTC")
    addition = f"[{stamp}] {text[:1000]}"
    claim.extra_proof = f"{claim.extra_proof}\n{addition}" if claim.extra_proof else addition
    system_message(claim, "The claimant added more ownership proof. It is visible to the finder in the claim panel.")
    notify(claim.item.owner, Kind.CLAIM_RECEIVED,
           f"New proof added to claim #{claim.claim_id} for \"{claim.item.title}\".", _chat_link(claim))
    audit("claim.proof_added", "claim", claim.claim_id, actor=user)


def _check_finder(claim, actor):
    if not (actor.user_id == claim.item.owner_id or actor.is_admin):
        raise WorkflowError("Only the finder can decide on this claim.")


def approve_claim(claim, actor):
    _check_finder(claim, actor)
    item = claim.item
    if claim.status != ClaimStatus.PENDING:
        raise WorkflowError("Only pending claims can be approved.")
    if item.status not in (ItemStatus.CLAIM_REQUESTED, ItemStatus.ACTIVE):
        raise WorkflowError("This item can't accept an approval right now.")

    claim.status = ClaimStatus.APPROVED
    claim.decided_at = utcnow()
    item.status = ItemStatus.CLAIM_APPROVED
    system_message(claim, "The finder verified the ownership proof and approved this claim. "
                          "Agree on a safe, approved campus hand-over point below.")
    notify(claim.claimant, Kind.CLAIM_APPROVED,
           f"Your claim for \"{item.title}\" was approved. Arrange a safe hand-over.", _chat_link(claim))

    # Only one owner: other open claims are declined.
    for other in _open_claims(item, exclude_id=claim.claim_id):
        other.status = ClaimStatus.REJECTED
        other.decided_at = utcnow()
        other.decision_note = "Another claim was verified for this item."
        system_message(other, "This claim was closed because another ownership claim was verified.")
        notify(other.claimant, Kind.CLAIM_REJECTED,
               f"Your claim for \"{item.title}\" was closed: another claim was verified.", _chat_link(other))
    audit("claim.approved", "claim", claim.claim_id, f"item {item.item_id}", actor=actor)


def reject_claim(claim, actor, note=None):
    _check_finder(claim, actor)
    if claim.status not in ClaimStatus.OPEN:
        raise WorkflowError("This claim is already closed.")
    item = claim.item
    claim.status = ClaimStatus.REJECTED
    claim.decided_at = utcnow()
    claim.decision_note = (note or "").strip()[:255] or None
    who = "An administrator" if actor.is_admin and actor.user_id != item.owner_id else "The finder"
    system_message(claim, f"{who} rejected this claim." + (f" Note: {claim.decision_note}" if claim.decision_note else ""))
    notify(claim.claimant, Kind.CLAIM_REJECTED,
           f"Your claim for \"{item.title}\" was not approved.", _chat_link(claim))
    _refresh_item_status(item)
    audit("claim.rejected", "claim", claim.claim_id, claim.decision_note, actor=actor)


def mark_returned(claim, actor):
    if actor.user_id != claim.item.owner_id and not actor.is_admin:
        raise WorkflowError("Only the finder can mark the item as returned.")
    if claim.status != ClaimStatus.APPROVED:
        raise WorkflowError("Approve the claim before marking the item as returned.")
    item = claim.item
    now = utcnow()
    claim.status = ClaimStatus.RETURNED
    claim.returned_at = now
    item.status = ItemStatus.COMPLETED
    item.completed_at = now

    # The claimant's own lost report is resolved too.
    if claim.lost_item is not None and claim.lost_item.status in ItemStatus.OPEN:
        claim.lost_item.status = ItemStatus.COMPLETED
        claim.lost_item.completed_at = now

    system_message(claim, "The item was handed over and marked as returned. This conversation is now closed.")
    notify(claim.claimant, Kind.ITEM_RETURNED,
           f"\"{item.title}\" was marked as returned to you. Case completed.", _chat_link(claim))
    audit("item.returned", "item", item.item_id, f"claim {claim.claim_id}", actor=actor)


def close_item(item, actor, reason):
    """Reporter closes their own report (lost item recovered, or found item
    handed to the campus office). The record is kept."""
    if actor.user_id != item.owner_id:
        raise WorkflowError("Only the person who reported this item can close it.")
    if item.status not in ItemStatus.OPEN:
        raise WorkflowError("This report is already closed.")
    if item.is_found and _open_claims(item):
        raise WorkflowError("Resolve the open claims on this item first.")
    now = utcnow()
    if item.is_lost and reason == "recovered":
        item.status = ItemStatus.COMPLETED
    else:
        item.status = ItemStatus.CLOSED
    item.completed_at = now
    audit("item.closed", "item", item.item_id, reason, actor=actor)


def admin_remove_item(item, admin, note=None):
    if item.status == ItemStatus.REMOVED:
        raise WorkflowError("This report is already removed.")
    for claim in _open_claims(item):
        claim.status = ClaimStatus.REJECTED
        claim.decided_at = utcnow()
        claim.decision_note = "Report removed by an administrator."
        system_message(claim, "An administrator removed this report. The conversation is closed.")
        notify(claim.claimant, Kind.ADMIN_NOTICE,
               f"The report \"{item.title}\" was removed by an administrator.", None)
    item.status = ItemStatus.REMOVED
    notify(item.owner, Kind.ADMIN_NOTICE,
           f"Your report \"{item.title}\" was removed by an administrator." + (f" Reason: {note}" if note else ""), None)
    audit("item.removed", "item", item.item_id, note, actor=admin)


def admin_restore_item(item, admin):
    if item.status != ItemStatus.REMOVED:
        raise WorkflowError("Only removed reports can be restored.")
    item.status = ItemStatus.ACTIVE
    item.completed_at = None
    audit("item.restored", "item", item.item_id, actor=admin)


def item_from_id(item_id):
    return db.session.get(Item, item_id)
