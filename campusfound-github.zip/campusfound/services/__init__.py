"""Business logic, kept separate from the HTTP routes so it can be reused
(and replaced) by future API endpoints, background jobs or AI modules."""
