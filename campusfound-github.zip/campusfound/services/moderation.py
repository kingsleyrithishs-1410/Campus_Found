"""Chat safety rules for item conversations.

``check_message`` returns a verdict:
  * blocked  - the message is not saved and the sender sees why
               (phone numbers, links, email addresses, payment details, abuse)
  * flagged  - the message is saved but marked for admin review
               (home-address talk, meeting off campus, rewards)

The regular expressions are intentionally simple; a smarter classifier
(e.g. AI scam detection) can be plugged in through EXTRA_CHECKS.
"""
import re
from dataclasses import dataclass

MAX_MESSAGE_LENGTH = 1000

PHONE_RE = re.compile(r"(?:\+?\d[\s\-().]*){10,}")
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
UPI_RE = re.compile(r"\b[\w.\-]{2,}@(?:ok)?[a-z]{2,12}\b", re.I)
URL_RE = re.compile(
    r"(https?://|www\.|\b[a-z0-9-]+\.(?:com|net|org|in|io|co|me|ly|xyz|app|link|info|biz|edu)\b)",
    re.I,
)
PAYMENT_RE = re.compile(
    r"\b(upi|gpay|g\s?pay|google\s?pay|phone\s?pe|phonepe|paytm|bhim|paypal|venmo|"
    r"bank\s?account|account\s?(?:no|number)|ifsc|card\s?number|cvv|otp|"
    r"send\s+(?:me\s+)?money|transfer\s+(?:the\s+)?money|pay\s+me|deposit|advance\s+payment)\b",
    re.I,
)
ADDRESS_RE = re.compile(
    r"\b(home\s+address|my\s+address|your\s+address|house\s+(?:no|number)|flat\s+(?:no|number)|"
    r"my\s+(?:house|home|flat|apartment|pg)|come\s+to\s+my|outside\s+campus|off\s+campus)\b",
    re.I,
)
REWARD_RE = re.compile(r"\b(reward|fee|charge|payment|pay\s+for|cash|rupees|rs\.?|₹|\$)\b", re.I)

# A short placeholder list - extend it for your campus language(s).
ABUSIVE_WORDS = {
    "idiot", "stupid", "moron", "loser", "dumb", "bastard", "bitch", "fuck", "fucking",
    "shit", "asshole", "slut", "whore", "retard", "kill you", "hurt you",
}
ABUSE_RE = re.compile(r"\b(" + "|".join(re.escape(w) for w in sorted(ABUSIVE_WORDS)) + r")\b", re.I)


@dataclass
class Verdict:
    allowed: bool
    flagged: bool = False
    reason: str = ""


EXTRA_CHECKS = []   # future: callables (body) -> Verdict | None


def check_message(body):
    text = (body or "").strip()
    if not text:
        return Verdict(False, reason="Type a message before sending.")
    if len(text) > MAX_MESSAGE_LENGTH:
        return Verdict(False, reason=f"Messages can be at most {MAX_MESSAGE_LENGTH} characters.")
    if ABUSE_RE.search(text):
        return Verdict(False, reason="Abusive language isn't allowed. Keep the conversation respectful.")
    if PAYMENT_RE.search(text):
        return Verdict(False, reason="Payment details and money requests aren't allowed. Never send money to another user.")
    if EMAIL_RE.search(text) or UPI_RE.search(text):
        return Verdict(False, reason="Email addresses and payment IDs can't be shared here. Keep contact inside this conversation.")
    if PHONE_RE.search(text):
        return Verdict(False, reason="Phone numbers can't be shared here. Arrange the hand-over in this conversation. Put serial numbers in your ownership proof instead.")
    if URL_RE.search(text):
        return Verdict(False, reason="Links can't be shared in item conversations.")
    for check in EXTRA_CHECKS:
        verdict = check(text)
        if verdict is not None:
            return verdict
    if ADDRESS_RE.search(text):
        return Verdict(True, flagged=True, reason="Mentions a personal address or an off-campus meeting")
    if REWARD_RE.search(text):
        return Verdict(True, flagged=True, reason="Mentions money or a reward")
    return Verdict(True)


def check_report_text(text):
    """Lighter checks for public report descriptions (no links, phones or emails)."""
    if not text:
        return None
    if PHONE_RE.search(text):
        return "Remove phone numbers from the description. Others can reach you through the claim conversation."
    if EMAIL_RE.search(text):
        return "Remove email addresses from the description."
    if URL_RE.search(text):
        return "Links aren't allowed in reports."
    if ABUSE_RE.search(text):
        return "Remove abusive language from the description."
    return None
