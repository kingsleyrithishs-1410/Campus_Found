"""Possible-match suggestions between lost and found reports.

The score (0-100) combines several independent signals. Each signal is a small
"scorer" function, so smarter scorers (AI description similarity, image
similarity) can be appended to SCORERS later without touching the callers.

Matching only ever *recommends*. It never confirms ownership: ownership is
decided by the finder after reviewing private proof.
"""
import math
import re
from dataclasses import dataclass, field

from flask import current_app

from models import Item, ItemStatus, ItemType
from services.settings import get_setting

STOP_WORDS = {
    "the", "and", "with", "for", "from", "near", "inside", "outside", "has", "have",
    "was", "were", "this", "that", "its", "very", "some", "one", "two", "lost",
    "found", "item", "small", "big", "large", "left", "right", "around", "about",
    "colour", "color", "it's", "my", "your", "our", "there", "which", "into", "onto",
}

# Words that carry a lot of identity for campus items.
COLOR_WORDS = {
    "black", "white", "blue", "red", "green", "yellow", "brown", "grey", "gray",
    "pink", "purple", "orange", "silver", "gold", "golden", "navy", "maroon", "beige",
}

MATCHABLE_STATUSES = (ItemStatus.ACTIVE, ItemStatus.CLAIM_REQUESTED)


def tokens(text):
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    return {w for w in words if len(w) >= 3 and w not in STOP_WORDS}


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def haversine_m(lat1, lng1, lat2, lng2):
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def distance_between(a, b):
    if None in (a.latitude, a.longitude, b.latitude, b.longitude):
        return None
    return haversine_m(a.latitude, a.longitude, b.latitude, b.longitude)


@dataclass
class MatchResult:
    item: Item
    score: int
    reasons: list = field(default_factory=list)
    distance_m: float = None
    nearby: bool = False

    @property
    def strength(self):
        if self.score >= 75:
            return "Strong possible match"
        if self.score >= 55:
            return "Possible match"
        return "Weak possible match"


# --------------------------------------------------------------------------
# Individual scorers: (lost, found, ctx) -> (points, reason or None)
# --------------------------------------------------------------------------
def score_category(lost, found, ctx):
    if lost.category == found.category:
        return 30, f"Same category ({lost.category})"
    return 0, None


def score_title(lost, found, ctx):
    a, b = tokens(lost.title), tokens(found.title)
    overlap = a & b
    # A shared colour alone ("black") is not a similar name; colours count in the description score.
    if not overlap - COLOR_WORDS:
        return 0, None
    points = round(25 * max(jaccard(a, b), 0.5 if overlap else 0))
    return min(points, 25), "Similar name: " + ", ".join(sorted(overlap))


def score_description(lost, found, ctx):
    a = tokens(lost.description) | tokens(lost.title)
    b = tokens(found.description) | tokens(found.title)
    overlap = a & b
    if not overlap:
        return 0, None
    colours = overlap & COLOR_WORDS
    points = round(10 * jaccard(a, b) * 2) + (5 if colours else 0)
    reason = None
    if colours:
        reason = "Same colour: " + ", ".join(sorted(colours))
    elif len(overlap) >= 2:
        reason = "Shared details: " + ", ".join(sorted(overlap)[:4])
    return min(points, 15), reason


def score_location(lost, found, ctx):
    """Location is only one factor and can never produce a match on its own."""
    same_name = lost.location_name.strip().lower() == found.location_name.strip().lower()
    dist = ctx.get("distance")
    nearby_m = ctx["nearby_meters"]
    if same_name:
        return 15, f"Same place ({found.location_name})"
    if dist is not None and dist <= nearby_m:
        ctx["nearby"] = True
        return 12, f"Possible nearby match: about {int(round(dist, -1))} m from {lost.location_name}"
    if dist is not None and dist <= nearby_m * 2:
        ctx["nearby"] = True
        return 6, f"Possible nearby match: about {int(round(dist, -1))} m away"
    return 0, None


def score_date(lost, found, ctx):
    days = (found.event_date - lost.event_date).days
    if days < -2:
        # Found more than two days before it was lost: almost certainly different items.
        ctx["impossible"] = True
        return 0, None
    gap = abs(days)
    if gap <= 1:
        return 15, "Reported within a day of each other"
    if gap <= 3:
        return 10, f"Reported {gap} days apart"
    if gap <= 7:
        return 5, f"Reported {gap} days apart"
    return 0, None


SCORERS = [score_category, score_title, score_description, score_location, score_date]


def score_pair(lost, found):
    ctx = {
        "distance": distance_between(lost, found),
        "nearby_meters": get_setting("nearby_meters"),
        "nearby": False,
        "impossible": False,
    }
    total, reasons = 0, []
    for scorer in SCORERS:
        points, reason = scorer(lost, found, ctx)
        total += points
        if reason:
            reasons.append(reason)
    if ctx["impossible"]:
        total = 0
    other = found
    return MatchResult(
        item=other, score=min(int(total), 100), reasons=reasons,
        distance_m=ctx["distance"], nearby=ctx["nearby"],
    )


def find_matches(item, limit=6, threshold=None):
    """Return possible matches for ``item`` from the opposite report type."""
    if threshold is None:
        threshold = get_setting("match_threshold")
    opposite = ItemType.FOUND if item.is_lost else ItemType.LOST
    candidates = (
        Item.query.filter(
            Item.item_type == opposite,
            Item.status.in_(MATCHABLE_STATUSES),
            Item.owner_id != item.owner_id,
            Item.item_id != item.item_id,
        )
        .order_by(Item.created_at.desc())
        .limit(500)
        .all()
    )
    results = []
    for other in candidates:
        lost, found = (item, other) if item.is_lost else (other, item)
        result = score_pair(lost, found)
        result.item = other
        # Category or name must agree: location/date alone never make a match.
        has_identity_signal = any(
            r.startswith(("Same category", "Similar name")) for r in result.reasons
        )
        if has_identity_signal and result.score >= threshold:
            results.append(result)
    results.sort(key=lambda r: r.score, reverse=True)
    current_app.logger.debug("Matches for item %s: %s", item.item_id, [(r.item.item_id, r.score) for r in results])
    return results[:limit]
