"""Email sending for verification links.

If MAIL_SERVER is empty the message is written to the application log, which
is enough for development. Configure SMTP settings in .env for production.
"""
import smtplib
from email.message import EmailMessage

from flask import current_app
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

VERIFY_SALT = "email-verify"
VERIFY_MAX_AGE = 3 * 24 * 3600


def _serializer():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt=VERIFY_SALT)


def make_verification_token(user):
    return _serializer().dumps({"uid": user.user_id, "email": user.email})


def read_verification_token(token):
    try:
        data = _serializer().loads(token, max_age=VERIFY_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None
    return data


def send_email(to, subject, body):
    cfg = current_app.config
    if not cfg.get("MAIL_SERVER"):
        current_app.logger.warning("Email (console backend) to %s: %s\n%s", to, subject, body)
        return True
    msg = EmailMessage()
    msg["From"] = cfg["MAIL_FROM"]
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(cfg["MAIL_SERVER"], cfg["MAIL_PORT"], timeout=15) as smtp:
            if cfg.get("MAIL_USE_TLS"):
                smtp.starttls()
            if cfg.get("MAIL_USERNAME"):
                smtp.login(cfg["MAIL_USERNAME"], cfg["MAIL_PASSWORD"])
            smtp.send_message(msg)
        return True
    except (smtplib.SMTPException, OSError) as exc:
        current_app.logger.error("Could not send email to %s: %s", to, exc)
        return False
