"""Admin-editable application settings stored in the app_settings table.

Defaults come from config.py; a value saved by an administrator overrides it.
"""
from flask import current_app

from extensions import db
from models import AppSetting

# key -> (label, type, config key for the default)
SETTINGS_SCHEMA = {
    "campus_name": ("Campus name", str, "CAMPUS_NAME"),
    "campus_lat": ("Campus map centre latitude", float, "CAMPUS_LAT"),
    "campus_lng": ("Campus map centre longitude", float, "CAMPUS_LNG"),
    "campus_zoom": ("Campus map zoom (14-19)", int, "CAMPUS_ZOOM"),
    "match_threshold": ("Possible-match score threshold (0-100)", int, "MATCH_THRESHOLD"),
    "nearby_meters": ("'Nearby' distance in metres", int, "NEARBY_METERS"),
}

FALLBACKS = {}


def get_setting(key):
    label, cast, config_key = SETTINGS_SCHEMA[key]
    row = db.session.get(AppSetting, key)
    if row is not None:
        try:
            return cast(row.value)
        except (TypeError, ValueError):
            pass
    if config_key:
        return cast(current_app.config[config_key])
    return FALLBACKS.get(key, "")


def set_setting(key, raw_value):
    """Validate and store a setting. Raises ValueError on bad input."""
    label, cast, _ = SETTINGS_SCHEMA[key]
    value = cast(str(raw_value).strip())
    if key == "campus_lat" and not -90 <= value <= 90:
        raise ValueError("Latitude must be between -90 and 90.")
    if key == "campus_lng" and not -180 <= value <= 180:
        raise ValueError("Longitude must be between -180 and 180.")
    if key == "campus_zoom" and not 14 <= value <= 19:
        raise ValueError("Zoom must be between 14 and 19.")
    if key == "match_threshold" and not 0 <= value <= 100:
        raise ValueError("Threshold must be between 0 and 100.")
    if key == "nearby_meters" and not 10 <= value <= 5000:
        raise ValueError("Nearby distance must be between 10 and 5000 metres.")
    if key == "campus_name":
        value = value[:80]
        if not value:
            raise ValueError("Campus name cannot be empty.")
    row = db.session.get(AppSetting, key)
    if row is None:
        row = AppSetting(key=key, value=str(value))
        db.session.add(row)
    else:
        row.value = str(value)
    return value


def all_settings():
    return {key: get_setting(key) for key in SETTINGS_SCHEMA}


def map_config():
    return {
        "lat": get_setting("campus_lat"),
        "lng": get_setting("campus_lng"),
        "zoom": get_setting("campus_zoom"),
    }
