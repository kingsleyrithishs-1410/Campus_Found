"""Audit log helper: records who did what, for admin history and disputes."""
from flask import g, has_request_context, request

from extensions import db
from models import AuditLog


def audit(action, target_type=None, target_id=None, details=None, actor=None):
    if actor is None and has_request_context():
        actor = getattr(g, "user", None)
    ip = None
    if has_request_context():
        ip = (request.remote_addr or "")[:45]
    entry = AuditLog(
        actor_id=actor.user_id if actor else None,
        action=action,
        target_type=target_type,
        target_id=target_id,
        details=(details or "")[:255] or None,
        ip_address=ip,
    )
    db.session.add(entry)
    return entry
