"""Safe image uploads.

Every upload is:
  * checked against an extension allow-list (png, jpg, jpeg, webp),
  * size-limited (5 MB by default),
  * opened with Pillow to prove it really is an image of an allowed format,
  * re-encoded to a fresh file, which strips EXIF metadata (including GPS
    coordinates) and any non-image payload,
  * stored under a random name outside the static folder.

Item photos go to uploads/items (served through a route). Ownership-proof
photos go to uploads/private/proofs and are only served after an
authorization check.
"""
import io
import os
import uuid

from flask import current_app
from PIL import Image, ImageOps, UnidentifiedImageError

FORMAT_BY_EXTENSION = {"png": "PNG", "jpg": "JPEG", "jpeg": "JPEG", "webp": "WEBP"}
EXTENSION_BY_FORMAT = {"PNG": "png", "JPEG": "jpg", "WEBP": "webp"}


class UploadError(ValueError):
    pass


def item_upload_dir():
    return os.path.join(current_app.config["UPLOAD_ROOT"], "items")


def proof_upload_dir():
    return os.path.join(current_app.config["UPLOAD_ROOT"], "private", "proofs")


def ensure_upload_dirs():
    for path in (item_upload_dir(), proof_upload_dir()):
        os.makedirs(path, exist_ok=True)


def scan_for_malware(path):
    """Hook for virus scanning (e.g. ClamAV via clamd) in production.

    Re-encoding with Pillow already discards anything that is not pixel data,
    so this returns True by default. Replace with a real scanner if required.
    """
    return True


def has_file(file_storage):
    return bool(file_storage and file_storage.filename)


def save_image(file_storage, private=False):
    """Validate, sanitise and store an uploaded image. Returns the stored filename."""
    cfg = current_app.config
    filename = file_storage.filename or ""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext not in cfg["ALLOWED_IMAGE_EXTENSIONS"]:
        raise UploadError("Photos must be PNG, JPG, JPEG or WEBP files.")

    max_bytes = cfg["MAX_IMAGE_BYTES"]
    data = file_storage.stream.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise UploadError(f"Photos must be {max_bytes // (1024 * 1024)} MB or smaller.")
    if not data:
        raise UploadError("The selected photo is empty.")

    try:
        probe = Image.open(io.BytesIO(data))
        probe.verify()
        image = Image.open(io.BytesIO(data))
        image.load()
    except (UnidentifiedImageError, OSError, SyntaxError, Image.DecompressionBombError):
        raise UploadError("That file is not a valid image.")

    fmt = image.format
    if fmt not in EXTENSION_BY_FORMAT:
        raise UploadError("Photos must be PNG, JPG, JPEG or WEBP files.")

    image = ImageOps.exif_transpose(image)
    image.thumbnail((cfg["IMAGE_MAX_DIMENSION"], cfg["IMAGE_MAX_DIMENSION"]))
    if fmt == "PNG" and image.mode not in ("RGB", "RGBA", "L", "LA", "P"):
        image = image.convert("RGBA")
    if fmt == "WEBP" and image.mode not in ("RGB", "RGBA"):
        image = image.convert("RGBA")
    if fmt == "JPEG" and image.mode not in ("RGB", "L"):
        image = image.convert("RGB")

    out_ext = EXTENSION_BY_FORMAT[fmt]
    stored_name = f"{uuid.uuid4().hex}.{out_ext}"
    directory = proof_upload_dir() if private else item_upload_dir()
    os.makedirs(directory, exist_ok=True)
    path = os.path.join(directory, stored_name)

    save_kwargs = {"quality": 85} if fmt in ("JPEG", "WEBP") else {"optimize": True}
    # Saving without passing exif/info drops all metadata.
    image.save(path, format=fmt, **save_kwargs)

    if not scan_for_malware(path):
        os.remove(path)
        raise UploadError("The file was rejected by the security scanner.")
    return stored_name


def delete_image(stored_name, private=False):
    if not stored_name:
        return
    directory = proof_upload_dir() if private else item_upload_dir()
    path = os.path.join(directory, os.path.basename(stored_name))
    if os.path.isfile(path):
        os.remove(path)
